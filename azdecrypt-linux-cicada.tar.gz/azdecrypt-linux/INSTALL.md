# Installing AZdecrypt

Find your distribution below and run the commands in order. Each block is
self-contained — copy the whole thing.

Every path needs two things: **FreeBASIC** (the compiler) and **GTK3** (the GUI
toolkit). Most distributions package GTK3 but not FreeBASIC, so FreeBASIC is
usually a manual step. It takes about a minute.

---

## Debian / Ubuntu / Mint / Pop!\_OS / Kali / Raspberry Pi OS

```bash
# 1. system libraries
sudo apt update
sudo apt install -y build-essential pkg-config libgtk-3-dev zlib1g-dev \
                    libjemalloc-dev libncurses-dev libx11-dev libxext-dev \
                    libxrender-dev libxrandr-dev libxpm-dev wget

# 2. FreeBASIC - use the ubuntu-22.04 build, it links against ncurses 6
wget https://downloads.sourceforge.net/fbc/FreeBASIC-1.10.1-ubuntu-22.04-x86_64.tar.gz
tar xf FreeBASIC-1.10.1-ubuntu-22.04-x86_64.tar.gz
cd FreeBASIC-1.10.1-ubuntu-22.04-x86_64
sudo ./install.sh -i
cd ..
fbc -version

# 3. build
cd azdecrypt-linux
./build.sh portable
```

If `fbc -version` fails with `libtinfo.so.5: cannot open shared object file`,
you downloaded one of the older builds. Either grab the ubuntu-22.04 one above,
or install the compat library:

```bash
wget -4 http://ftp.debian.org/debian/pool/main/n/ncurses/libtinfo5_6.4-4_amd64.deb
sudo dpkg -i libtinfo5_6.4-4_amd64.deb
```

---

## Arch / Manjaro / EndeavourOS / Garuda / CachyOS

FreeBASIC is in the AUR, so this is the easiest distribution to set up.

```bash
sudo pacman -S --needed base-devel pkgconf gtk3 zlib jemalloc ncurses \
                        libx11 libxext libxrender libxrandr libxpm

# FreeBASIC from the AUR (yay, paru, or any helper)
yay -S freebasic

cd azdecrypt-linux
./build.sh portable
```

No AUR helper? Build it by hand:

```bash
git clone https://aur.archlinux.org/freebasic.git
cd freebasic && makepkg -si && cd ..
```

---

## Fedora / RHEL / Rocky / Alma / Nobara

```bash
sudo dnf install -y gcc gcc-c++ make pkgconf-pkg-config gtk3-devel \
                    zlib-devel jemalloc-devel ncurses-devel \
                    libX11-devel libXext-devel libXrender-devel \
                    libXrandr-devel libXpm-devel ncurses-compat-libs wget

wget https://downloads.sourceforge.net/fbc/FreeBASIC-1.10.1-ubuntu-22.04-x86_64.tar.gz
tar xf FreeBASIC-1.10.1-ubuntu-22.04-x86_64.tar.gz
cd FreeBASIC-1.10.1-ubuntu-22.04-x86_64
sudo ./install.sh -i
cd ..
fbc -version

cd azdecrypt-linux
./build.sh portable
```

`ncurses-compat-libs` is included above in case you use one of the older
FreeBASIC builds, which need `libtinfo.so.5`.

---

## openSUSE Leap / Tumbleweed

```bash
sudo zypper install -y gcc gcc-c++ make pkg-config gtk3-devel zlib-devel \
                       jemalloc-devel ncurses-devel libX11-devel \
                       libXext-devel libXrender-devel libXrandr-devel \
                       libXpm-devel wget

wget https://downloads.sourceforge.net/fbc/FreeBASIC-1.10.1-ubuntu-22.04-x86_64.tar.gz
tar xf FreeBASIC-1.10.1-ubuntu-22.04-x86_64.tar.gz
cd FreeBASIC-1.10.1-ubuntu-22.04-x86_64
sudo ./install.sh -i
cd ..

cd azdecrypt-linux
./build.sh portable
```

---

## Void

Both dependencies are packaged. This is a two-liner.

```bash
sudo xbps-install -Sy base-devel pkg-config gtk+3-devel zlib-devel \
                      jemalloc-devel ncurses-devel libX11-devel \
                      libXext-devel libXrender-devel libXrandr-devel \
                      libXpm-devel freebasic

cd azdecrypt-linux
./build.sh portable
```

---

## Gentoo

```bash
sudo emerge --noreplace x11-libs/gtk+ sys-libs/zlib dev-libs/jemalloc \
                        sys-libs/ncurses x11-libs/libX11 x11-libs/libXext \
                        x11-libs/libXrender x11-libs/libXrandr \
                        x11-libs/libXpm dev-lang/fbc

cd azdecrypt-linux
./build.sh portable
```

---

## Alpine

Alpine uses musl, and FreeBASIC's official builds are glibc-linked, so the
compiler has to be built from source.

```bash
sudo apk add build-base pkgconf gtk+3.0-dev zlib-dev jemalloc-dev \
             ncurses-dev libx11-dev libxext-dev libxrender-dev \
             libxrandr-dev libxpm-dev git

git clone https://github.com/freebasic/fbc.git
cd fbc && make -j"$(nproc)" && sudo make install && cd ..

cd azdecrypt-linux
./build.sh portable
```

Budget 15–20 minutes for the compiler build.

---

## If a `wget` for FreeBASIC fails

SourceForge sometimes blocks command-line downloads. Open this page in a
browser and click the ubuntu-22.04 x86_64 link instead:

<https://sourceforge.net/projects/fbc/files/FreeBASIC-1.10.1/Binaries-Linux/>

Then:

```bash
tar xf FreeBASIC-1.10.1-ubuntu-22.04-x86_64.tar.gz
cd FreeBASIC-1.10.1-ubuntu-22.04-x86_64
sudo ./install.sh -i
```

---

## Any other distribution

Install these however your package manager spells them:

- a C toolchain (gcc or clang, make)
- pkg-config
- GTK3 **development** files
- zlib **development** files
- ncurses development files
- X11 development files: libX11, libXext, libXrender, libXrandr, libXpm
- jemalloc (optional, improves multithreaded performance)

Then install FreeBASIC 1.10 or newer from <https://www.freebasic.net/get>, and
run `./build.sh`.

The helper script will check your environment and tell you what's missing:

```bash
./install.sh --check
```

---

## Automatic install

`install.sh` does everything above automatically for the distributions listed:

```bash
./install.sh
```

It detects your package manager, installs dependencies, builds, and installs to
`~/.local`. Useful flags:

| Flag | Effect |
|---|---|
| `--check` | Verify the environment, change nothing |
| `--build-only` | Skip dependency install |
| `--system` | Install to `/usr/local` instead of `~/.local` |
| `--yes` | Don't prompt |

---

## After building

```bash
./AZdecrypt
```

Or install it properly:

```bash
./install.sh --build-only
azdecrypt
```

If `azdecrypt` isn't found, add `~/.local/bin` to your `PATH`.

### N-gram files

**Not included** — they're hundreds of megabytes and identical on every
platform. Copy them from a Windows AZdecrypt install into `N-grams/`.
No conversion needed.

The same applies to `Ciphers/` and `Misc/`.

---

## Build options

```bash
./build.sh              # optimised for this machine
./build.sh portable     # optimised, generic - use if sharing the binary
./build.sh debug        # bounds checking, for diagnosing crashes
./build.sh nojemalloc   # skip jemalloc
```

---

## Troubleshooting

**`fbc: error while loading shared libraries: libtinfo.so.5`**
FreeBASIC's official build wants ncurses 5. Install `libtinfo5` (Debian/Ubuntu,
see above) or `ncurses-compat-libs` (Fedora). Do **not** symlink `libtinfo.so.6`
to `.so.5` — the symbol versions differ and it fails at a later stage.

**`GTK3 development files not found`**
You have GTK3's runtime but not its headers. Install the `-dev` / `-devel`
package.

**`Package gtk+-3.0 was not found`**
pkg-config can't see GTK3. Same fix as above.

**`Task: none` / `Error: file not found` from the solver**
The n-gram files aren't in place. Copy them into `N-grams/` (see below). This is
not an error in the program.

**Window opens but controls overlap or clip**
AZdecrypt uses a fixed pixel layout. The port pins a compact UI font to match it,
but an unusual desktop theme can still shift things. Override the font size:

```bash
AZDECRYPT_FONT_PX=10 ./AZdecrypt
```

**Maximizing leaves empty space**
Expected. AZdecrypt is a fixed-layout application and doesn't reflow — there's
nothing to stretch into the extra space. It behaves the same way on Windows.

**Radio buttons in one window act as a single group**
GTK groups radio buttons explicitly where Win32 does it implicitly; grouping is
reconstructed from creation order. See `README.md`.

**Out of memory**
Use a 64-bit system. The n-gram tables are large.

---

## Uninstalling

```bash
./uninstall.sh              # remove program, keep data
./uninstall.sh --purge      # remove everything
./uninstall.sh --system     # if installed with --system
```
