# Cicada 3301 / Liber Primus tooling

Runic cryptanalysis support built on top of the Linux port. It adds a **Cicada**
menu and a set of runic cipher operations, working on the 29-rune Gematria Primus
alphabet.

## Why nothing in the solver changed

AZdecrypt stores a cipher as `info()`, an array of integers (not bytes), and its
parser already accepts space-separated numbers. The hill-climbing solver is
general over integer symbol alphabets.

So runes need no engine changes — only transcoding at the boundary:

```
  runic text  ──►  integers 1..29  ──►  existing AZdecrypt solver
   (UTF-8)          (rune index+1)       (unmodified)
```

Symbol `0` is reserved for word separators (`-` and `.` in Liber Primus). Every
Cicada operation passes `0` through untouched, because word boundaries are what
make cribs work.

## Solving with the hill-climber

**The existing AZdecrypt solver already works on runes.** Its hill-climber is
generic over alphabet size — key generation, scoring, and the crib alphabet all
read `ngram_alphabet_size` rather than assuming 26. When you load a runeglish
n-gram set, the solver's plaintext alphabet becomes those characters, and
substitution, transposition, and substitution+transposition all operate on runic
ciphers with no engine changes.

That means Caesar and Atbash fall out for free: both are substitutions, so the
substitution solver finds them without needing a dedicated mode.

### Setup

1. **Populate the Ciphers folder** with the Liber Primus. Three ways, pick one:

   - **In the app:** *Cicada > Download Liber Primus pages...* — asks first, then
     fetches and writes the pages.
   - **During install:** `install.sh` offers to do it as its last step.
   - **From a shell:**

     ```bash
     python3 make_lp_ciphers.py
     ```

   All three write one file per page — `LP_page_00.txt` through
   `LP_page_57.txt` — as space-separated rune indices with `0` marking word
   breaks, plus a `.runes` copy of each page for reference. Source is the
   rtkd/iddqd community master transcription.

   Needs `python3` and a network connection. No network? Download the
   transcription by hand and pass it in:

   ```bash
   python3 make_lp_ciphers.py --source liber-primus__transcription--master.txt
   ```

2. **Load runeglish n-grams** — Functions > Load n-grams, pick a runeglish set.
   These use the runic alphabet (with `T G E I X` standing in for the digraphs),
   which is what makes the solver score runic plaintext correctly. English
   n-grams will not work on runes.

3. **Open a page** — File > Open, pick `LP_page_NN.txt`.

4. **Pick a solver** and run it. Substitution is the place to start; the
   transposition and substitution+transposition solvers work the same way.

### Reading the result

Solver output is in the n-gram alphabet. Use **Cicada > Numbers to latin** on the
cipher to read a candidate as Latin, or **Numbers to runes** to see it as futhorc.

### What to expect

The solved LP pages used Atbash and Vigenère, and those are already broken. The
unsolved pages have resisted straightforward substitution for years — a
hill-climber will not crack them by brute force alone. The value here is being
able to test hypotheses quickly: apply a candidate transform with the Cicada
operations, then check whether the result scores like structured text.

## Workflow

1. Paste runic text into the input window.
2. **Cicada → Runes to numbers** (or *keep separators* to preserve word breaks).
3. Apply Cicada operations, or run the normal solver — it now sees a 29-symbol cipher.
4. **Cicada → Numbers to latin** to read a candidate plaintext.

## Menus

The Cicada features are split across three menus by what they do to your work:
one converts, one measures, one searches.

### Cicada — transcoding and display

| Item | Effect |
|---|---|
| Runes to numbers | Transcode runes → `1..29`, discard punctuation |
| Runes to numbers (keep separators) | As above, but word breaks become `0` |
| Numbers to runes | Inverse |
| Numbers to latin | Read out as Latin transliteration |
| Runes to latin (direct) | Transliterate without numeric round-trip; preserves layout |
| Latin to runes | Encode Latin → futhorc (greedy digraph matching) |
| Toggle letter forms | Switch between V/U, K/C, Z/S, ING/NG, IO/IA readings |
| Cycle stats symbol display | Show statistics symbols as characters, runes, or numbers |
| Gematria Primus table | Reference table |
| Download Liber Primus pages... | Fetch the LP and write one cipher file per page into `Ciphers/` |

### Cicada analysis — measure the cipher

Read-only. Nothing here modifies the input; results go to the output pane.

| Item | Effect |
|---|---|
| Rune frequency | Sorted counts, percentages, unused runes, IOC |
| Bigrams and doublets | Doublet rate against random expectation, top bigrams |
| Runic index of coincidence | Single IOC figure with interpretation |
| Index of coincidence by period | IOC per coset for periods 1..40, with a bar chart |
| Kasiski examination | Repeated n-grams and a factor histogram of their distances |
| Gematria sum | Sum of rune primes; reports primality and totient |
| Gematria by word, with prime hunting | Per-word sums and primality, totals, prime rate |
| Totient chain of the total | Repeated totient down to 1 |

### Cicada solve — search for a key

These run on a background thread; the UI stays live and *Stop* works.

| Item | Effect |
|---|---|
| Vigenere key (hill-climb) | Periodic key, scanned across lengths 2..32 |
| Autokey primer (hill-climb) | Primer, then plaintext feedback |
| Running key (free key stream) | One value per rune — read the caveat below |
| Scan closed-form transforms | Enumerates atbash (either order) × shift × key stream family |
| Stop | Ends a running solve; partial results are still written |

## Cicada operations (Manipulation window)

Selectable in the Manipulation list. **A1** carries the argument.

| Operation | A1 | Notes |
|---|---|---|
| `Cicada: atbash` | — | `i → 28-i`, self-inverse |
| `Cicada: shift` | shift amount | Caesar over 29 runes |
| `Cicada: vigenere (decrypt/encrypt)` | key, e.g. `DIVINITY` | Key advances on runes only, not separators |
| `Cicada: prime shift (decrypt/encrypt)` | — | Position *i* shifted by *i*-th prime mod 29 |
| `Cicada: totient shift (decrypt/encrypt)` | — | Shifted by `(prime−1) mod 29` |
| `Cicada: euler totient shift (decrypt/encrypt)` | — | Shifted by `totient(i) mod 29` |
| `Cicada: fibonacci shift (decrypt/encrypt)` | — | Shifted by the Fibonacci sequence mod 29 |
| `Cicada: running key (decrypt/encrypt)` | key text | Key does **not** repeat; runes past its end pass through |
| `Cicada: autokey (decrypt/encrypt)` | primer | Primer, then the plaintext becomes the key |

The key-advance rule matters: on the solved Liber Primus pages, separators do not
consume key material, and that's the behaviour here.

## Cipher math verification

The operations were cross-checked against an independent Python implementation:

```
Atbash self-inverse:                OK
Shift round-trip:                   OK
Vigenere round-trip:                OK
Atbash known-plaintext round-trip:  OK    (AWARNING → RNGRAMEW → AWARNING)
Digraph greedy match:               OK    (THE → [TH, E], 2 runes not 3)
IOC discriminates:                  OK    (random 0.0345, english-ish 0.0656)
Autokey round trip:                 OK
Running key round trip:             OK
Running key tail untouched:         OK    (key does not repeat)
Fibonacci shift round trip:         OK
Euler totient shift round trip:     OK
Runeglish map matches corpus script:OK    (29 distinct chars)
IOC by period finds planted length: OK    (planted 11, found 11)
Kasiski peaks at planted length:    OK    (planted 11)
```

Planted-key recovery, run end to end against 4-gram sets built from a 750 KB
corpus, ciphers of 900 runes. Both alphabet layouts tested:

```
29-symbol runeglish set
  Vigenere,  planted DIVINITY (8)       -> recovered, 109053 vs 50706 next
  Autokey,   planted CIRCUMFERENCE (13) -> recovered, 109053 vs 7679 next
  Scan,      planted atbash+shift7+primes -> found,   109053 vs 5677 next

22-symbol Latin set (digraphs spelled out)
  Vigenere,  planted DIVINITY (8)       -> recovered, 50410 vs 24945 next
  Autokey,   planted CIRCUMFERENCE (13) -> recovered
  Scan,      planted atbash+shift7+primes -> found
```

The Latin set separates the true key from the runners-up by a narrower margin
(2.0x vs 2.2x on Vigenere). Expanding runes to letters means a 4-gram covers
only two or three runes instead of four, so it constrains the key less. If a
solve looks marginal, a 29-symbol set or a longer n-gram is the lever.

The scan ties "shift 8 + totient primes" with "shift 7 + primes" at the same
score. That is correct, not a defect: totient primes are prime−1, so the shift
absorbs the difference and the two describe the same transform.

The running key mode is not covered by a recovery test, and cannot be — see the
caveat above.

The IOC figures match theory: `1/29 = 0.0345` for random runic text, higher for
English transliterated into futhorc — the discriminator between a monoalphabetic
and a polyalphabetic candidate.

The Gematria Primus table was validated against Python's `unicodedata`: all 29
codepoints distinct, in the Runic block, with correct Unicode names.

## The Gematria Primus table

The rune → Latin → prime mapping follows the commonly published Cicada table. If
your source orders or transliterates differently, it's one contiguous block at the
top of `cicada_gematria.bi`, laid out to be edited in place.

## Notes

- **Digraph ambiguity when encoding.** Greedy longest-match means `THE` encodes as
  `TH,E`. If a passage genuinely intends `T,H,E`, this mis-encodes. Unavoidable
  without word context; only affects Latin → runes.

- **IOC on short texts.** Liber Primus pages are short. Below ~200 runes the IOC
  estimate is noisy — treat the interpretation banding as a hint, not a verdict.

- **`prime_nth` uses trial division.** Fine for key lengths and rune positions. If
  prime-shift solving ever becomes a hot loop, precompute a sieve.

## Key stream solvers

The base AZdecrypt hill-climber searches over a *substitution* — an unknown
mapping from cipher symbol to plaintext symbol. That's the wrong shape for the
Liber Primus hypotheses, where the mapping is known (shift by k mod 29) and the
*key stream* is what's unknown. The solvers in `cicada_solver.bi` hill-climb the
key instead.

They share the part that matters with the base engine: scoring. They read the
same `g2..g7` / `bh` tables the solver threads read, through the same `ngp()`
power curve, so a score here is directly comparable to a score there, and
improving the n-gram tables improves both.

They run on a background thread, so the UI stays live and *Solve: stop* works.

| Mode | Search space | Notes |
|---|---|---|
| Vigenère key | 29^L per length L | Scans lengths 2..32, reports best per length |
| Autokey primer | 29^L per primer length | Primer then plaintext feedback |
| Running key | 29 per rune position | See the warning below |
| Transform scan | 435 exact evaluations | Closed form, no search — scores are exact |

Length scores are normalised before comparison, since a longer key trivially
fits any text better.

### Requirements

An n-gram set built from **runeglish** text. Two layouts work, and the solver
detects which it has:

**29-symbol** — one character per rune, as `corpus_to_runeglish.py --format
ngrams` emits. Digraph runes get their own symbol, so rune and symbol are 1:1.

**Latin (22-symbol)** — digraphs spelled out, which is what you get from
ordinary transliterated text. The runes only ever spell with `ABCDEFGHIJLMNOPRSTUWXY`
— K, Q, V and Z never appear, because C absorbs K and Q, U absorbs V, and S
absorbs Z. So the alphabet lands on 22, not 26 and not 29. Here a rune maps to
one *or two* symbols, and the solver expands each candidate rune to its letters
before scoring. The alternate readings (V/U, K/C, Z/S, ING/NG, IO/IA) are tried
per-rune, so a set built with either convention works.

Either way the solver refuses rather than guessing if some rune has no spelling
the alphabet can represent, and the run header states which layout it detected.

Scores are not comparable between the two layouts — the Latin set scores more
positions per rune, and its 4-grams span fewer runes.

The neural (`nn`) n-gram system isn't supported here; it needs solver-thread
state that doesn't exist on this path.

### The running key caveat

A free key stream has one unknown per rune, so **any** plaintext is reachable
and the search will always return fluent-looking text. The n-gram score cannot
tell a real decryption from a fitted one. The evidence is the key: a genuine
running key is itself a passage of text. If the derived key reads as gibberish,
you have a fit, not a solve. The solver prints both and says so.

## Building a runeglish corpus

`corpus_to_runeglish.py` converts an English corpus into the runeglish encoding
the Liber Primus uses, so you can generate n-grams that score runic plaintext.

```bash
python3 corpus_to_runeglish.py corpus.txt runeglish.txt --workers 16
python3 corpus_to_runeglish.py corpus.zip quadgrams.txt --format ngrams --ngram-size 4
```

The input can be a plain file or a `.zip` of many files. Zip members are
concatenated into one output; `.gz` members are inflated automatically, and
anything non-text is reported rather than silently dropped. Use `--filter` to
restrict to members whose name contains a string.

The encoding gives each of the 29 runes one character: lowercase for single
runes, uppercase as digraph markers (`T`=TH, `G`=NG/ING, `E`=EO, `O`=OE, `A`=AE,
`I`=IA/IO, `X`=EA). Latin letters with no rune fold onto their homophone —
`c` and `q` become `k`, `u` becomes `v`, `z` becomes `s`.

The file is split into byte ranges and processed in parallel, so memory stays
flat regardless of corpus size. Output is identical whatever the worker count.

Feed the resulting n-gram file through `convert_ngrams.py` to get the log-scaled
format AZdecrypt loads.

## Files

| File | Contents |
|---|---|
| `cicada_gematria.bi` | Gematria Primus table, UTF-8 rune handling, transcoding, number theory |
| `cicada_ciphers.bi` | Atbash, shifts, Vigenère, running key, key generators, gematria sum, runic IOC |
| `cicada_analysis.bi` | IOC by period, Kasiski, frequency, bigrams, gematria by word, totient chains |
| `cicada_solver.bi` | Rune→alphabet mapping, n-gram scoring, key stream annealing |
| `thread_cicada_solve.bi` | Background worker driving the solvers |

## Fixed

`Runes to numbers (keep separators)` compared the menu id against the wrong
constant, so it never actually kept separators — it behaved identically to the
plain conversion. Word breaks now survive, which matters because they're what
make cribs work.

The scan applies atbash both before and after the key stream, since the two
orderings are different ciphers and a scan that only covered one would miss the
other. An early version covered only `atbash then key` and failed to find a
planted `key then atbash` cipher; both are enumerated now.
