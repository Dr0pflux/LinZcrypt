# Cicada 3301 / Liber Primus tooling

Runic cryptanalysis support added to AZdecrypt, on top of the Linux/GTK3 port.

**Status: compiles-untested**, same caveat as the port itself — no FreeBASIC compiler
was available. The *cipher mathematics*, however, **was** verified: a Python reference
implementation of the same algorithms passes round-trip and known-plaintext tests
(see *Verification* below). The Gematria Primus table was checked rune-by-rune
against the Unicode character database.

---

## Design: why nothing in the solver changed

AZdecrypt stores a cipher as `info()`, an array of `long` — integer symbols, not
bytes — with `identmax = 65535`. Its parser already has a **numerical mode**:
space-separated integers. The hill-climbing solver is general over integer symbol
alphabets.

So runes need no engine changes. They need transcoding at the boundary:

```
  runic text  ──►  integers 1..29  ──►  existing AZdecrypt solver
   (UTF-8)          (rune index+1)       (unmodified)
```

Symbol `0` is reserved for word separators (`-` and `.` in Liber Primus). Every
Cicada operation passes `0` through untouched — important, because word boundaries
are what make cribs work, and shifting them would destroy that structure.

---

## Workflow

1. Paste runic text into the input window.
2. **Cicada → Runes to numbers** (or *keep separators* to preserve word breaks).
3. Apply operations, or run the normal solver — it now sees a 29-symbol cipher.
4. **Cicada → Numbers to latin** to read a candidate plaintext.

---

## Menu: Cicada

| Item | Purpose |
|---|---|
| Runes to numbers | Transcode runes → `1..29`, discard punctuation |
| Runes to numbers (keep separators) | As above, but word breaks become `0` |
| Numbers to runes | Inverse |
| Numbers to latin | Read out as Latin transliteration |
| Runes to latin (direct) | Transliterate without numeric round-trip; preserves layout |
| Latin to runes | Encode Latin → futhorc (greedy digraph matching) |
| Gematria sum | Sum of rune primes; reports primality and totient |
| Runic index of coincidence | IOC against the 29-rune alphabet, with interpretation |
| Gematria Primus table | Reference table |

## Manipulation window: Cicada operations

Selectable in the Manipulation list. **A1** carries the argument.

| Operation | A1 | Notes |
|---|---|---|
| `Cicada: atbash` | — | `i → 28-i`, self-inverse |
| `Cicada: shift` | shift amount | Caesar over 29 runes |
| `Cicada: vigenere (decrypt/encrypt)` | key, e.g. `DIVINITY` | Key advances on runes only, not separators |
| `Cicada: prime shift (decrypt/encrypt)` | — | Position *i* shifted by *i*-th prime mod 29 |
| `Cicada: totient shift (decrypt/encrypt)` | — | Shifted by `(prime−1) mod 29` |

The key-advance rule matters. On the solved Liber Primus pages, separators do **not**
consume key material — that's the behaviour implemented here.

---

## Additional primitives (in `cicada_ciphers.bi`, not yet on menus)

Written and available to call, but with no UI attached yet:

- `cic_runningkey` — running-key Vigenère, key drawn from another passage or the
  cipher itself at an offset. Widely suspected for the unsolved pages.
- `cic_key_primes`, `cic_key_totient`, `cic_key_totient_primes`, `cic_key_fibonacci`
  — key-stream generators.
- `prime_nth`, `is_prime`, `totient` — number theory helpers.

Wiring these to the UI is the obvious next increment.

---

## Verification

The cipher math was ported to Python and tested independently:

```
Atbash self-inverse:                OK
Shift round-trip:                   OK
Vigenere round-trip:                OK
Atbash known-plaintext round-trip:  OK    (AWARNING → RNGRAMEW → AWARNING)
Digraph greedy match:               OK    (THE → [TH, E], 2 runes not 3)
IOC discriminates:                  OK    (random 0.0345, english-ish 0.0656)
```

The IOC figures land exactly where theory predicts: `1/29 = 0.0345` for random
runic text, meaningfully higher for English transliterated into futhorc. That's
the discriminator for telling a monoalphabetic candidate from a polyalphabetic one.

The Gematria Primus table was validated against `unicodedata`: all 29 codepoints
distinct, in the Runic block, with correct Unicode names. **This caught three real
errors** — I had initially misassigned A, Æ and Y. The correct values are
`A = U+16AA (AC)`, `AE = U+16AB (AESC)`, `Y = U+16A3 (YR)`.

---

## Known risks

1. **Compilation.** Untested, like the port. Most likely issues are FreeBASIC's
   `chr()` with multiple byte arguments, and array-parameter passing conventions in
   the `cic_*` routines.

2. **Gematria Primus rune assignment.** The table is verified *internally consistent*
   and Unicode-correct, but the mapping of runes to Latin values and primes follows
   the commonly published Cicada table. If you're working from a source that orders
   or transliterates differently, edit the table in `cicada_gematria.bi` — it's one
   contiguous, commented block, deliberately.

3. **Digraph ambiguity in `Latin to runes`.** Greedy longest-match means `THE`
   becomes `TH,E`. If a passage genuinely intends `T,H,E`, this will mis-encode.
   Unavoidable without word-level context; matters only for the encode direction.

4. **`prime_nth` is trial division.** Fine for key lengths and rune positions; would
   be slow if called for very large *n* in a tight solver loop. If prime-shift
   solving becomes a hot path, precompute a sieve.

5. **IOC on short texts.** Liber Primus pages are short. Below ~200 runes, the IOC
   estimate is noisy and the interpretation banding will mislead. Treat it as a hint.

---

## Files

| File | Contents |
|---|---|
| `cicada_gematria.bi` | Gematria Primus table, UTF-8 rune handling, transcoding, number theory |
| `cicada_ciphers.bi` | Atbash, shifts, Vigenère, running key, key generators, gematria sum, runic IOC |

Changes to existing files: `AZdecrypt.bas` (includes, globals, 5 operations, menu,
handlers), `window_controls_manipulation.bi` (A1 wiring),
`window_main_menucommands.bi` (9 command handlers).
