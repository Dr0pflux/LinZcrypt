# Cicada 3301 / Liber Primus tooling

Runic cryptanalysis support built on top of the Linux port. It adds a **Cicada**
menu and a set of runic cipher operations, working on the 29-rune Gematria Primus
alphabet.

## Why nothing in the solver changed

AZdecrypt stores a cipher as `info()`, an array of integers (not bytes), and its
parser already accepts space-separated numbers. The hill-climbing solver is
general over integer symbol alphabets.

So runes need no engine changes — only transcoding at the boundary:

```
  runic text  ──►  integers 1..29  ──►  existing AZdecrypt solver
   (UTF-8)          (rune index+1)       (unmodified)
```

Symbol `0` is reserved for word separators (`-` and `.` in Liber Primus). Every
Cicada operation passes `0` through untouched, because word boundaries are what
make cribs work.

## Solving with the hill-climber

**The existing AZdecrypt solver already works on runes.** Its hill-climber is
generic over alphabet size — key generation, scoring, and the crib alphabet all
read `ngram_alphabet_size` rather than assuming 26. When you load a runeglish
n-gram set, the solver's plaintext alphabet becomes those characters, and
substitution, transposition, and substitution+transposition all operate on runic
ciphers with no engine changes.

That means Caesar and Atbash fall out for free: both are substitutions, so the
substitution solver finds them without needing a dedicated mode.

### Setup

1. **Populate the Ciphers folder** with the Liber Primus. Three ways, pick one:

   - **In the app:** *Cicada > Download Liber Primus pages...* — asks first, then
     fetches and writes the pages.
   - **During install:** `install.sh` offers to do it as its last step.
   - **From a shell:**

     ```bash
     python3 make_lp_ciphers.py
     ```

   All three write one file per page — `LP_page_00.txt` through
   `LP_page_57.txt` — as space-separated rune indices with `0` marking word
   breaks, plus a `.runes` copy of each page for reference. Source is the
   rtkd/iddqd community master transcription.

   Needs `python3` and a network connection. No network? Download the
   transcription by hand and pass it in:

   ```bash
   python3 make_lp_ciphers.py --source liber-primus__transcription--master.txt
   ```

2. **Load runeglish n-grams** — Functions > Load n-grams, pick a runeglish set.
   These use the runic alphabet (with `T G E I X` standing in for the digraphs),
   which is what makes the solver score runic plaintext correctly. English
   n-grams will not work on runes.

3. **Open a page** — File > Open, pick `LP_page_NN.txt`.

4. **Pick a solver** and run it. Substitution is the place to start; the
   transposition and substitution+transposition solvers work the same way.

### Reading the result

Solver output is in the n-gram alphabet. Use **Cicada > Numbers to latin** on the
cipher to read a candidate as Latin, or **Numbers to runes** to see it as futhorc.

### What to expect

The solved LP pages used Atbash and Vigenère, and those are already broken. The
unsolved pages have resisted straightforward substitution for years — a
hill-climber will not crack them by brute force alone. The value here is being
able to test hypotheses quickly: apply a candidate transform with the Cicada
operations, then check whether the result scores like structured text.

## Workflow

1. Paste runic text into the input window.
2. **Cicada → Runes to numbers** (or *keep separators* to preserve word breaks).
3. Apply Cicada operations, or run the normal solver — it now sees a 29-symbol cipher.
4. **Cicada → Numbers to latin** to read a candidate plaintext.

## Cicada menu

| Item | Purpose |
|---|---|
| Runes to numbers | Transcode runes → `1..29`, discard punctuation |
| Runes to numbers (keep separators) | As above, but word breaks become `0` |
| Numbers to runes | Inverse |
| Numbers to latin | Read out as Latin transliteration |
| Runes to latin (direct) | Transliterate without numeric round-trip; preserves layout |
| Latin to runes | Encode Latin → futhorc (greedy digraph matching) |
| Gematria sum | Sum of rune primes; reports primality and totient |
| Runic index of coincidence | IOC against the 29-rune alphabet, with interpretation |
| Gematria Primus table | Reference table |
| Toggle letter forms | Switch between V/U, K/C, Z/S, ING/NG, IO/IA readings |
| Cycle stats symbol display | Show statistics symbols as characters, runes, or numbers |
| Download Liber Primus pages... | Fetch the LP and write one cipher file per page into `Ciphers/` |

## Cicada operations (Manipulation window)

Selectable in the Manipulation list. **A1** carries the argument.

| Operation | A1 | Notes |
|---|---|---|
| `Cicada: atbash` | — | `i → 28-i`, self-inverse |
| `Cicada: shift` | shift amount | Caesar over 29 runes |
| `Cicada: vigenere (decrypt/encrypt)` | key, e.g. `DIVINITY` | Key advances on runes only, not separators |
| `Cicada: prime shift (decrypt/encrypt)` | — | Position *i* shifted by *i*-th prime mod 29 |
| `Cicada: totient shift (decrypt/encrypt)` | — | Shifted by `(prime−1) mod 29` |

The key-advance rule matters: on the solved Liber Primus pages, separators do not
consume key material, and that's the behaviour here.

## Cipher math verification

The operations were cross-checked against an independent Python implementation:

```
Atbash self-inverse:                OK
Shift round-trip:                   OK
Vigenere round-trip:                OK
Atbash known-plaintext round-trip:  OK    (AWARNING → RNGRAMEW → AWARNING)
Digraph greedy match:               OK    (THE → [TH, E], 2 runes not 3)
IOC discriminates:                  OK    (random 0.0345, english-ish 0.0656)
```

The IOC figures match theory: `1/29 = 0.0345` for random runic text, higher for
English transliterated into futhorc — the discriminator between a monoalphabetic
and a polyalphabetic candidate.

The Gematria Primus table was validated against Python's `unicodedata`: all 29
codepoints distinct, in the Runic block, with correct Unicode names.

## The Gematria Primus table

The rune → Latin → prime mapping follows the commonly published Cicada table. If
your source orders or transliterates differently, it's one contiguous block at the
top of `cicada_gematria.bi`, laid out to be edited in place.

## Notes

- **Digraph ambiguity when encoding.** Greedy longest-match means `THE` encodes as
  `TH,E`. If a passage genuinely intends `T,H,E`, this mis-encodes. Unavoidable
  without word context; only affects Latin → runes.

- **IOC on short texts.** Liber Primus pages are short. Below ~200 runes the IOC
  estimate is noisy — treat the interpretation banding as a hint, not a verdict.

- **`prime_nth` uses trial division.** Fine for key lengths and rune positions. If
  prime-shift solving ever becomes a hot loop, precompute a sieve.

## Not yet wired to the UI

`cicada_ciphers.bi` also contains a running-key Vigenère (`cic_runningkey` — the
leading hypothesis for the unsolved pages) and several key-stream generators
(`cic_key_primes`, `cic_key_totient`, `cic_key_totient_primes`,
`cic_key_fibonacci`). They're implemented and callable; they just don't have menu
entries yet. That's the obvious next addition.

## Building a runeglish corpus

`corpus_to_runeglish.py` converts an English corpus into the runeglish encoding
the Liber Primus uses, so you can generate n-grams that score runic plaintext.

```bash
python3 corpus_to_runeglish.py corpus.txt runeglish.txt --workers 16
python3 corpus_to_runeglish.py corpus.zip quadgrams.txt --format ngrams --ngram-size 4
```

The input can be a plain file or a `.zip` of many files. Zip members are
concatenated into one output; `.gz` members are inflated automatically, and
anything non-text is reported rather than silently dropped. Use `--filter` to
restrict to members whose name contains a string.

The encoding gives each of the 29 runes one character: lowercase for single
runes, uppercase as digraph markers (`T`=TH, `G`=NG/ING, `E`=EO, `O`=OE, `A`=AE,
`I`=IA/IO, `X`=EA). Latin letters with no rune fold onto their homophone —
`c` and `q` become `k`, `u` becomes `v`, `z` becomes `s`.

The file is split into byte ranges and processed in parallel, so memory stays
flat regardless of corpus size. Output is identical whatever the worker count.

Feed the resulting n-gram file through `convert_ngrams.py` to get the log-scaled
format AZdecrypt loads.

## Files

| File | Contents |
|---|---|
| `cicada_gematria.bi` | Gematria Primus table, UTF-8 rune handling, transcoding, number theory |
| `cicada_ciphers.bi` | Atbash, shifts, Vigenère, running key, key generators, gematria sum, runic IOC |
