# AZdecrypt — Linux/GTK3 port

Port of Jarlve's AZdecrypt from Win32 to Linux, retaining the full GUI.

**Status: compiles-untested.** This code was written and statically audited but never
run through `fbc`, because the porting environment had no FreeBASIC compiler. Expect
to fix errors on the first build. See *Known risks* below for where they will most
likely be.

For the Cicada 3301 / Liber Primus runic tooling, see `README-CICADA.md`.

---

## Build

```bash
sudo apt install freebasic libgtk-3-dev zlib1g-dev libjemalloc-dev pkg-config
./build.sh
```

If FreeBASIC is not packaged for your distro, get it from
<https://www.freebasic.net/get> (need **≥ 1.10, 64-bit**).

Modes:

| Command | Effect |
|---|---|
| `./build.sh` | optimised (`-O 3 -march=native`) |
| `./build.sh debug` | `-g -exx`, bounds checking |
| `./build.sh nojemalloc` | skip jemalloc if unavailable |

Run from a directory containing `Ciphers/`, `Output/`, `Misc/`, `N-grams/`.
These are created on first launch. **N-gram and wordlist `.txt`/`.gz` files are
platform-neutral — copy them over from the Windows install unchanged.**

---

## How the port works

The key discovery: **the application never calls Win32 directly.** Every GUI
operation goes through a `ui_*` wrapper in `ui_specific.bi`, and Jarlve had already
added `#ifdef __fb_linux__` branches to all 39 of them — they were just empty stubs
returning `0` / `""`.

So the port did not require touching the ~63,000 lines of application and solver
code. It required implementing those 39 functions against GTK3, plus four
platform fixes in `AZdecrypt.bas`.

```
  application code (~63k lines, UNCHANGED)
            │
            ▼
      ui_*  (ui_specific.bi)          ← 39 functions, both platforms
       │                    │
       ▼                    ▼
  win_gui.bi           gtk_widgets.bi  ← new
  win_dialogs.bi       gtk_backend.bi  ← new
   (Windows)              (Linux)
```

### New files

| File | Purpose |
|---|---|
| `gtk_backend.bi` | Message-pump bridge, window registry, signal handlers |
| `gtk_widgets.bi` | GTK implementations of the widget primitives |
| `ui_specific.bi` | Rewritten — Linux branches now call the GTK backend |

### The message-pump bridge

This was the one genuinely hard part. The application drives a **pull** loop:

```basic
do
    sleep 0.001
    if getmessage(@msg,0,0,0)<>0 then
        select case msg.hwnd
            case button_x : if msg.message=wm_lbuttondown then ...
```

GTK is **push** (signals/callbacks). The bridge inverts it: GTK signal handlers
push synthetic `MSG` records onto a mutex-guarded ring buffer, and
`gtkbe_getmessage()` pumps pending GTK events then pops one record. The
application's dispatch logic is untouched.

This works because the app's message surface turned out to be tiny — verified by
exhaustive grep across all sources:

- fields: `msg.hwnd`, `msg.message`, `msg.wparam`, `msg.w`
- events: `wm_command`, `wm_keyup`, `wm_lbuttondown`, `wm_rbuttondown`, `em_setsel`

Mapping:

| App expects | GTK source |
|---|---|
| `wm_lbuttondown` + `msg.hwnd` = widget | `"clicked"` on button/checkbox/radio |
| `wm_command` + `msg.wparam` = menu id | `"activate"` on `GtkMenuItem`, id stored via `g_object_set_data` |
| `wm_keyup` + `msg.wparam` = vkey | `"key-release-event"` |
| `em_setsel(0,-1)` | select-all on entry/textview |

### Changes to `AZdecrypt.bas`

Only four, all platform-conditional:

1. **Main loop** — the `#ifdef __fb_linux__ / #else` block spanned the *entire* loop
   body, so on Linux the program compiled but did nothing at all. The conditional
   now closes right after the Win32 pump, so the shared dispatch logic runs on both
   platforms; the Linux branch feeds `msg` from `gtkbe_getmessage()`.
2. **`GetCPUCores`** — inline `asm cpuid` replaced with
   `sysconf(_SC_NPROCESSORS_ONLN)` on Linux. The original was x86-only *and*
   misreports on many modern CPUs (leaf `0x0A` is the performance-monitoring leaf,
   not a core count).
3. **Includes** — `win/shlobj.bi` and the bundled Windows `libjemalloc.a` are now
   Windows-only; Linux links system libraries.
4. **Path separators** — 32 hardcoded `"\"` literals replaced with a `PSEP`
   constant. FreeBASIC's integer-division operator is also `\`, so the substitution
   was applied only inside string literals, verified by a quote-state parser.

---

## Known risks

Ranked by how likely they are to bite on first build.

1. **Compilation errors.** Nothing here has been through `fbc`. Most likely
   candidates are GTK binding signature mismatches — argument types, `byval` vs
   `byref`, or `gtk_list_store_set`'s varargs, which FreeBASIC handles differently
   from C. Paste errors back and they're quick to fix.

2. **Radio-button grouping.** Win32 groups radio buttons implicitly by creation
   order and `WS_GROUP`; GTK needs an explicit group pointer. The backend chains
   each new radio onto the previous one in the same parent window, breaking the
   chain when `WS_GROUP` is set. If the app creates two radio sets in one window
   *without* `WS_GROUP` on the second, they will merge into one group. Check the
   solver options and transposition windows first.

3. **Absolute layout.** The app positions every control with fixed Win32 pixel
   coordinates, so the port uses `GtkFixed`. Fonts differ between platforms, so
   labels may clip or overlap. Cosmetic, but expect to nudge sizes.

4. **`ui_destroywindow` hides rather than destroys.** The app reopens sub-windows
   by stored handle; destroying would invalidate every child handle it holds. Hiding
   preserves handle validity. Consequence: closed windows keep their widget state
   instead of resetting.

5. **Menu check marks.** `GtkMenuItem` has no check state, so `MF_CHECKED` renders
   as a `*` prefix on the label. Functional, ugly. Migrating to
   `GtkCheckMenuItem` would fix it properly.

6. **`ShellExecute`** ("open output folder") is stubbed out on Linux. One-line fix
   with `xdg-open` if you want it.

---

## Verification performed

Without a compiler, everything below was checked statically:

- Zero raw Win32 calls leak outside the wrapper files (exhaustive grep).
- All 39 `ui_*` functions called by the app are defined; no missing symbols.
- Preprocessor `#ifdef`/`#endif` balance is zero-sum in every modified file.
- All 20 GTK functions, 21 cast macros and 12 enum constants used were confirmed
  present in the bundled FreeBASIC GTK3 bindings.
- `PSEP` is defined before first use, at top level, on both platforms.

Two real bugs were caught this way: GTK cast macros are **uppercase**
(`GTK_WINDOW`, not `gtk_window` — the lowercase form collides with the type name),
and `gtk/gtk.bi` silently selects **GTK2** unless `__USE_GTK3__` is defined.
