# AZdecrypt for Linux

A Linux/GTK3 port of Jarlve's [AZdecrypt](https://www.zodiackillerciphers.com/wiki/index.php?title=AZdecrypt),
a fast cryptanalysis tool for substitution and transposition ciphers, with added
tooling for Cicada 3301 / Liber Primus runic ciphers.

The full GUI is preserved. The solver and all of AZdecrypt's original
functionality are unchanged.

- **Installing:** see [INSTALL.md](INSTALL.md) — per-distribution instructions.
- **Cicada / Liber Primus features:** see [README-CICADA.md](README-CICADA.md).

## Quick build

```bash
./build.sh portable
./AZdecrypt
```

You need FreeBASIC (≥ 1.10, 64-bit), GTK3, and zlib. INSTALL.md covers getting
these on every major distribution.

## Runtime layout

AZdecrypt works from a directory containing `Ciphers/`, `Output/`, `Misc/`, and
`N-grams/`, created automatically on first launch.

**N-gram files are not bundled** — they're large and identical across platforms.
Copy them from a Windows AZdecrypt install into `N-grams/`. They're plain
`.txt`/`.gz` and need no conversion. The same applies to `Ciphers/` and `Misc/`.

Without n-grams the solver reports `Error: file not found`; the rest of the
program still works.

### N-gram file format

AZdecrypt does not read raw occurrence counts. It expects a pre-scaled log value
in a fixed-width field — 3 digits, or 4 digits it divides by 10. A file of raw
counts is misparsed: `TH 176355` is read as score 176, and anything whose leading
digits exceed 255 gets clamped. That is what the message
`N-gram system log value overflows: NNNN` reports.

If you have raw-count n-gram files, convert them first:

```bash
python3 convert_ngrams.py merged_file_quadgrams.txt
```

This writes `merged_file_quadgrams_azd.txt` plus a matching `.ini`, rescaling the
counts into log space so relative ranking is preserved and nothing clips.

### N-grams without an .ini

AZdecrypt normally requires a matching `.ini` beside each n-gram file, holding the
n-gram size, alphabet, and weights. If that file is missing, this port scans the
n-gram file and generates one automatically — so a bare `.txt` of n-grams (a
runeglish quadgram list, for example) loads without hand-writing an `.ini`.

The generated file uses n-gram factor `1` and entropy weight `1`; adjust those in
the solver options if the defaults don't suit your corpus. Compressed (`.gz`) and
binary n-gram sets still need their own `.ini`, since they can't be scanned as
text.

## How the port works

AZdecrypt never calls Win32 directly — every GUI operation goes through a `ui_*`
wrapper. The port implements those wrappers against GTK3 in three new files, and
leaves the ~63,000 lines of application and solver code untouched.

| File | Purpose |
|---|---|
| `gtk_backend.bi` | Event-loop bridge, window registry, signal handlers, global styling |
| `gtk_widgets.bi` | GTK implementations of the widget primitives |
| `ui_specific.bi` | The `ui_*` layer: Windows branches call Win32, Linux branches call GTK |

The one non-trivial piece is the event loop. AZdecrypt pulls messages
(`getmessage` in a loop); GTK pushes them (signals/callbacks). The bridge inverts
this: GTK signal handlers enqueue synthetic message records onto a mutex-guarded
ring buffer, and the Linux `getmessage` drains that queue. The application's
dispatch logic runs unchanged on both platforms.

Changes to `AZdecrypt.bas` are all platform-conditional: the main loop feeds from
the GTK bridge on Linux, CPU-core detection uses `sysconf` instead of x86 `cpuid`,
the Windows-only jemalloc/shlobj includes are guarded, and path separators use a
`PSEP` constant.

## Build modes

```bash
./build.sh              # optimised, tuned to this machine (-march=native)
./build.sh portable     # optimised, generic — use if sharing the binary
./build.sh debug        # bounds checking, for diagnosing crashes
./build.sh nojemalloc   # skip jemalloc
```

`portable` compiles faster and avoids CPU-specific vectorization warnings; it's
the recommended default unless you're squeezing out solver speed on one machine.

## Notes and limitations

- **Fixed layout.** AZdecrypt positions every control at absolute pixel
  coordinates — it doesn't reflow, on Windows or here. Maximizing the window shows
  empty space because there's nothing to stretch. This is the application's design.

- **Radio-button grouping.** GTK groups radio buttons explicitly where Win32 does
  it implicitly. Grouping is reconstructed from creation order; if a window's radio
  sets ever behave as one group, that's the place to look.

- **Menu check marks** render as a `*` prefix on the label, since `GtkMenuItem`
  has no native check state.

- **"Open output folder"** is not wired up on Linux (it was a Win32 shell call).

## Credit

Original AZdecrypt by Jarlve. This port and the Cicada tooling are independent
additions.

Linux performance notes
-----------------------

Four platform-layer problems, all fixed. Sites are marked in the source.

1. `do : sleep 0.001 : loop until <flag>` busy-waits. On Windows FB's SLEEP ends
   in `Sleep(0)`, which yields. On Linux it ends in `select(0, ..., {0,0})`,
   which returns immediately and yields nothing, so each waiter spun at 100% of
   a core against the solver threads. Now `sched_yield()` via `az_yield`.
2. Plain `sleep n` takes the FB runtime's global lock on every call, serialising
   every solver thread. `sleep n, 1` skips it; every sleep now has it.
3. The main loop polled every 15 ms when idle. It now blocks in
   `gtk_main_iteration_do(TRUE)` with a 25 ms wake tick. Idle cost measured
   afterwards: 0.4% of one core.
4. UI queue entries are whole-widget replacements but were appended, so workers
   outran the drain rate and updates were dropped. `uiq_push` now coalesces.

Build flags: `-gen gcc` is explicit (fbc's `-O` and `-Wc` are honoured by no
other backend, and 32-bit x86 defaults to `-gen gas`), `-arch native` replaces
`-Wc -march=native`, plus `-fpu sse -vec 2` and tuning flags.

Also fixed, a crash rather than a slowdown: `thread_load_ngrams` is spawned
before the main loop's first `gtkbe_getmessage`, so the old `uiq_deferred()` —
which keyed off "has the loop started" — let that worker call
`gtk_text_buffer_set_text` directly, segfaulting inside libgobject.
`uiq_deferred()` now compares thread identity.

If solver throughput still looks low, try the thread count. Windows uses 3/4 of
logical cores; this port uses all of them. Options > Solver > CPU threads.

Menu self-test
--------------

    ./build.sh menutest
    ./AZdecrypt          # then read /tmp/menufuzz.log

Collects every menu item and posts each through the same path a click takes, so
handlers run in the app's own message loop. Each id is logged and flushed before
dispatch, so a fault leaves the guilty item as the last line. Three passes:
forward, reverse, shuffled.

Result: 199 items x 3 passes, no crash, no GTK warnings. Run with an empty input
box and again with a 240-rune cipher reloaded before every dispatch. The source
has 213 menu ids; the 14 that never fire are 13 commented out upstream plus
`Combine`, behind a disabled feature flag.

Compiled out entirely unless `-d AZ_MENUFUZZ` is passed.
