#!/usr/bin/env bash
#
# build.sh - build AZdecrypt for Linux (GTK3 backend)
#
# Usage:
#   ./build.sh              optimised build
#   ./build.sh debug        debug build with bounds checking
#   ./build.sh nojemalloc   build without jemalloc
#   ./build.sh portable     optimised, but no -march=native (distributable binary)
#   ./build.sh menutest     diagnostic: on launch, fires every menu item three
#                           times (forward, reverse, shuffled) and logs each to
#                           /tmp/menufuzz.log before dispatching it, so if one
#                           faults the last line names it. Not for normal use.
#
# Environment overrides:
#   FBC=/path/to/fbc        use a specific FreeBASIC compiler
#   EXTRA_FBFLAGS="..."     append arbitrary flags
#
set -euo pipefail

MODE="${1:-release}"
FBC="${FBC:-fbc}"

# Helpers
die()  { printf 'error: %s\n' "$*" >&2; exit 1; }
note() { printf '  %s\n' "$*"; }

# pkg-config, then a link test, then ldconfig. The link test works on musl too.
have_lib() {
    local pc="$1" lib="$2" cc
    if [ -n "$pc" ] && command -v pkg-config >/dev/null 2>&1 && pkg-config --exists "$pc" 2>/dev/null; then
        return 0
    fi
    for cc in "${CC:-cc}" gcc clang; do
        if command -v "$cc" >/dev/null 2>&1; then
            if echo 'int main(void){return 0;}' | "$cc" -x c - -o /dev/null "-l$lib" >/dev/null 2>&1; then
                return 0
            fi
            break
        fi
    done
    if command -v ldconfig >/dev/null 2>&1 && ldconfig -p 2>/dev/null | grep -q "lib${lib}\.so"; then
        return 0
    fi
    return 1
}

# Gate -march=native: unsupported on some architectures.
cc_supports() {
    local flag="$1" cc
    for cc in "${CC:-cc}" gcc clang; do
        if command -v "$cc" >/dev/null 2>&1; then
            echo 'int main(void){return 0;}' | "$cc" -x c - -o /dev/null "$flag" >/dev/null 2>&1
            return $?
        fi
    done
    return 1
}

# Required tooling
command -v "$FBC" >/dev/null 2>&1 || die "FreeBASIC compiler '$FBC' not found.
  Install it from https://www.freebasic.net/get (need >= 1.10, 64-bit),
  or run ./install.sh which will guide you."

command -v pkg-config >/dev/null 2>&1 || die "pkg-config not found.
  Debian/Ubuntu: sudo apt install pkg-config
  Fedora:        sudo dnf install pkgconf-pkg-config
  Arch:          sudo pacman -S pkgconf
  Alpine:        sudo apk add pkgconf"

pkg-config --exists gtk+-3.0 2>/dev/null || die "GTK3 development files not found.
  Debian/Ubuntu: sudo apt install libgtk-3-dev
  Fedora:        sudo dnf install gtk3-devel
  Arch:          sudo pacman -S gtk3
  openSUSE:      sudo zypper install gtk3-devel
  Alpine:        sudo apk add gtk+3.0-dev
  Void:          sudo xbps-install gtk+3-devel"

have_lib "zlib" "z" || die "zlib development files not found.
  Debian/Ubuntu: sudo apt install zlib1g-dev
  Fedora:        sudo dnf install zlib-devel
  Arch:          sudo pacman -S zlib
  Alpine:        sudo apk add zlib-dev"

HAVE_JEMALLOC=0
if have_lib "jemalloc" "jemalloc"; then
    HAVE_JEMALLOC=1
fi

# Architecture: 32-bit compiles but the n-gram tables can exhaust address space.
ARCH="$(uname -m 2>/dev/null || echo unknown)"
case "$ARCH" in
    x86_64|amd64|aarch64|arm64|ppc64le|riscv64|s390x) ;;
    i?86|armv7l|armhf)
        printf 'warning: %s is a 32-bit target.\n' "$ARCH" >&2
        printf '         AZdecrypt allocates large n-gram tables and may run out of\n' >&2
        printf '         address space. A 64-bit system is strongly recommended.\n\n' >&2
        ;;
    *) printf 'warning: unrecognised architecture %s; proceeding anyway.\n\n' "$ARCH" >&2 ;;
esac

# Flags
FBFLAGS=( -m AZdecrypt )   # AZdecrypt.bas holds the main entry point
FBFLAGS+=( -mt )           # multithreaded runtime; the solver spawns threads
FBFLAGS+=( -w all )

# Force the gcc backend. It is already the default for x86_64, but not for
# 32-bit x86 (-gen gas) and not guaranteed on other targets. fbc's -O and -Wc
# are honoured ONLY by -gen gcc: with any other backend an optimised build
# silently becomes an unoptimised one.
FBFLAGS+=( -gen gcc )

# SSE floating point and the vectoriser. SSE is already implied on x86_64 but
# not on 32-bit x86, where the default is x87.
FBFLAGS+=( -fpu sse -vec 2 )

# gcc flags fbc has no option for. fbc appends -Wc contents after its own
# flags, so these win where they overlap.
TUNE_FLAGS="-funroll-loops,-fomit-frame-pointer"

case "$MODE" in
    release)
        FBFLAGS+=( -O 3 )
        # -arch native makes fbc emit -march=native itself. Passing it through
        # -Wc also works, but only because fbc happens to append -Wc last -
        # fbc always emits an -march of its own (x86-64 baseline by default),
        # so relying on argument order to override it is fragile.
        if cc_supports "-march=native"; then
            FBFLAGS+=( -arch native )
            FBFLAGS+=( -Wc "-mtune=native,$TUNE_FLAGS" )
            note "using -arch native (binary tuned to THIS machine)"
        else
            FBFLAGS+=( -Wc "$TUNE_FLAGS" )
            note "-march=native unsupported here; building generic"
        fi
        ;;
    portable)
        FBFLAGS+=( -O 3 )
        FBFLAGS+=( -Wc "$TUNE_FLAGS" )
        note "portable build: no -arch native"
        ;;
    debug)
        FBFLAGS+=( -g -exx )
        note "debug build: bounds checking enabled, slow"
        ;;
    nojemalloc)
        FBFLAGS+=( -O 3 )
        FBFLAGS+=( -Wc "$TUNE_FLAGS" )
        HAVE_JEMALLOC=0
        ;;
    menutest)
        FBFLAGS+=( -O 0 -d AZ_MENUFUZZ )
        note "menu self-test build - see /tmp/menufuzz.log after launching"
        ;;
    *)
        die "unknown mode '$MODE' (use release, portable, debug, nojemalloc or menutest)"
        ;;
esac

FBFLAGS+=( -l z )

if [ "$HAVE_JEMALLOC" -eq 1 ]; then
    FBFLAGS+=( -l jemalloc )
    note "linking jemalloc"
else
    FBFLAGS+=( -d AZ_NO_JEMALLOC )
    note "building WITHOUT jemalloc - expect slower multithreaded solving"
    note "  Debian/Ubuntu: sudo apt install libjemalloc-dev"
    note "  Fedora:        sudo dnf install jemalloc-devel"
    note "  Arch:          sudo pacman -S jemalloc"
    note "  then re-run ./build.sh"
fi

# GTK include and link flags, straight from pkg-config.
while IFS= read -r f; do
    case "$f" in
        -I*) FBFLAGS+=( -i "${f#-I}" ) ;;
    esac
done < <(pkg-config --cflags gtk+-3.0 | tr ' ' '\n')

while IFS= read -r f; do
    case "$f" in
        -l*) FBFLAGS+=( -l "${f#-l}" ) ;;
        -L*) FBFLAGS+=( -p "${f#-L}" ) ;;
    esac
done < <(pkg-config --libs gtk+-3.0 | tr ' ' '\n')

# Caller-supplied extras.
if [ -n "${EXTRA_FBFLAGS:-}" ]; then
    # shellcheck disable=SC2206  # deliberate word splitting of user-supplied flags
    EXTRA=( ${EXTRA_FBFLAGS} )
    FBFLAGS+=( "${EXTRA[@]}" )
fi

# Build
printf '\nBuilding AZdecrypt (mode: %s, arch: %s)\n' "$MODE" "$ARCH"
printf '%s %s AZdecrypt.bas\n\n' "$FBC" "${FBFLAGS[*]}"

"$FBC" "${FBFLAGS[@]}" AZdecrypt.bas

[ -x ./AZdecrypt ] || die "compilation finished but ./AZdecrypt was not produced"

printf '\nBuild complete: ./AZdecrypt\n\n'
printf 'Runtime layout (created automatically on first run):\n'
printf '  ./Ciphers/   ./Output/   ./Misc/   ./N-grams/\n\n'
printf 'N-gram files are not bundled. Copy them from a Windows install into ./N-grams/\n'
printf 'They are plain .txt/.gz and platform-neutral.\n'
