'cicada_analysis.bi - analysis tools for Cicada 3301 / Liber Primus

#ifndef CICADA_ANALYSIS_BI
#define CICADA_ANALYSIS_BI

#include once "cicada_ciphers.bi"

private function cic_pad(byref s as string, byval w as integer) as string
    if len(s) >= w then return s
    return s + space(w - len(s))
end function

private function cic_lpad(byref s as string, byval w as integer) as string
    if len(s) >= w then return s
    return space(w - len(s)) + s
end function

private function cic_bar(byval v as double, byval vmax as double, byval w as integer) as string
    if vmax <= 0 then return ""
    dim as integer n = cint((v / vmax) * w)
    if n < 0 then n = 0
    if n > w then n = w
    return string(n, "#")
end function

function cic_ioc_by_period(src() as long, byval l as integer, byval maxp as integer) as string

    dim as integer r(l + 1)
    dim as integer n = 0
    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            n += 1
            r(n) = v
        end if
    next

    if n < 20 then return "Error: need at least 20 runes for a period scan (have " + str(n) + ")."

    if maxp > n \ 4 then maxp = n \ 4
    if maxp < 1 then maxp = 1

    dim as double res(maxp)
    dim as double best = -1.0, worst = 1e9
    dim as integer bestp = 1

    for p as integer = 1 to maxp
        dim as double acc = 0.0
        dim as integer used = 0
        for c as integer = 0 to p-1
            dim as integer f(0 to GP_COUNT-1)
            dim as integer m = 0
            dim as integer i = c + 1
            while i <= n
                f(r(i)) += 1
                m += 1
                i += p
            wend
            if m >= 2 then
                dim as double num = 0.0
                for k as integer = 0 to GP_COUNT-1
                    num += cdbl(f(k)) * cdbl(f(k) - 1)
                next
                acc += num / (cdbl(m) * cdbl(m - 1))
                used += 1
            end if
        next
        if used > 0 then res(p) = acc / used else res(p) = 0.0
        if p > 1 then
            if res(p) > best then best = res(p) : bestp = p
            if res(p) < worst then worst = res(p)
        end if
    next

    dim as string o = "Index of coincidence by period" + lb
    o += "Runes analysed: " + str(n) + "   alphabet: 29   random baseline: 0.0345" + lb + lb

    dim as double vmax = res(1)
    for p as integer = 2 to maxp
        if res(p) > vmax then vmax = res(p)
    next

    o += "  p     IOC" + lb
    for p as integer = 1 to maxp
        dim as string mark = "  "
        if p > 1 andalso p = bestp then mark = "<-"
        o += cic_lpad(str(p), 3) + "   " + left(str(res(p)) + "00000", 6) + " " + _
             cic_bar(res(p), vmax, 40) + " " + mark + lb
    next

    o += lb
    if best < 0.040 then
        o += "No period stands out. Every coset looks random, which is what a" + lb
        o += "running key or an aperiodic key stream produces. A fixed-length" + lb
        o += "Vigenere key is unlikely below period " + str(maxp) + "." + lb
    else
        o += "Strongest period: " + str(bestp) + " (IOC " + left(str(res(bestp)) + "00000", 6) + ")." + lb
        dim as string mult = ""
        for p as integer = 2 to maxp
            if p mod bestp = 0 andalso res(p) >= best * 0.9 then mult += str(p) + " "
        next
        if len(mult) > 0 then
            o += "Reinforced at multiples: " + mult + lb
            o += "Multiples echoing the base period is the signature of a real key" + lb
            o += "length rather than a statistical accident." + lb
        end if
        o += lb + "Try: Cicada > Solve: Vigenere key, or set the key length by hand." + lb
    end if

    return o

end function

function cic_kasiski(src() as long, byval l as integer, byval glen as integer) as string

    dim as integer r(l + 1)
    dim as integer n = 0
    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            n += 1
            r(n) = v
        end if
    next

    if glen < 3 then glen = 3
    if glen > 8 then glen = 8
    if n < glen * 4 then return "Error: too few runes for a Kasiski scan."

    const KMAXF = 64
    dim as integer factor_hits(0 to KMAXF)
    dim as integer nrep = 0
    dim as longint dsum = 0
    dim as string examples = ""
    dim as integer nex = 0

    for i as integer = 1 to n - glen
        for j as integer = i + 1 to n - glen + 1
            dim as integer same = 1
            for k as integer = 0 to glen-1
                if r(i + k) <> r(j + k) then same = 0 : exit for
            next
            if same then
                dim as integer d = j - i
                nrep += 1
                dsum += d
                for f as integer = 2 to KMAXF
                    if d mod f = 0 then factor_hits(f) += 1
                next
                if nex < 8 then
                    dim as string g = ""
                    for k as integer = 0 to glen-1
                        g += gp_lat(r(i + k))
                    next
                    examples += "  " + cic_pad(g, 14) + " at " + cic_lpad(str(i), 5) + _
                                " and " + cic_lpad(str(j), 5) + "  distance " + str(d) + lb
                    nex += 1
                end if
            end if
        next
    next

    dim as string o = "Kasiski examination (" + str(glen) + "-gram repeats)" + lb
    o += "Runes analysed: " + str(n) + lb + lb

    if nrep = 0 then
        o += "No repeated " + str(glen) + "-grams at all." + lb + lb
        o += "For a text this length that points away from a short periodic key." + lb
        o += "Try a shorter n-gram length, or treat the key as aperiodic." + lb
        return o
    end if

    o += "Repeated " + str(glen) + "-grams: " + str(nrep) + lb
    o += "Mean distance: " + str(cint(dsum / nrep)) + lb + lb
    o += "Examples:" + lb + examples + lb

    dim as integer hmax = 0
    for f as integer = 2 to KMAXF
        if factor_hits(f) > hmax then hmax = factor_hits(f)
    next

    o += "Factor histogram (how many distances each factor divides):" + lb
    for f as integer = 2 to 40
        if factor_hits(f) > 0 then
            o += cic_lpad(str(f), 4) + "  " + cic_lpad(str(factor_hits(f)), 4) + "  " + _
                 cic_bar(factor_hits(f), hmax, 36) + lb
        end if
    next

    o += lb
    o += "Read the smallest factor with a tall bar as the candidate key length;" + lb
    o += "its multiples will be tall too, and are usually not separate answers." + lb

    return o

end function

function cic_freq_table(src() as long, byval l as integer) as string

    gp_init()

    dim as integer f(0 to GP_COUNT-1)
    dim as integer n = 0, seps = 0
    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            f(v) += 1
            n += 1
        elseif src(i) = 0 then
            seps += 1
        end if
    next

    if n = 0 then return "Error: no runic symbols (1..29) in the input."

    dim as integer ord(0 to GP_COUNT-1)
    for i as integer = 0 to GP_COUNT-1
        ord(i) = i
    next
    for i as integer = 0 to GP_COUNT-2
        for j as integer = 0 to GP_COUNT-2-i
            if f(ord(j)) < f(ord(j+1)) then swap ord(j), ord(j+1)
        next
    next

    dim as string o = "Rune frequency" + lb
    o += "Runes: " + str(n) + "   separators: " + str(seps) + _
         "   distinct: "
    dim as integer distinct = 0
    for i as integer = 0 to GP_COUNT-1
        if f(i) > 0 then distinct += 1
    next
    o += str(distinct) + " of 29" + lb + lb

    o += "  rune  latin   count   pct" + lb
    for k as integer = 0 to GP_COUNT-1
        dim as integer i = ord(k)
        dim as double pct = 100.0 * f(i) / n
        o += "  " + cic_pad(gp_rune(i), 5) + " " + cic_pad(gp_lat(i), 6) + " " + _
             cic_lpad(str(f(i)), 6) + "  " + cic_lpad(left(str(pct) + "000", 5), 6) + "  " + _
             cic_bar(f(i), f(ord(0)), 30) + lb
    next

    o += lb
    dim as double ic = cic_ioc(src(), l)
    o += "Runic IOC: " + left(str(ic) + "00000", 6) + "   (random 0.0345)" + lb
    if distinct < GP_COUNT then
        o += "Unused runes: "
        for i as integer = 0 to GP_COUNT-1
            if f(i) = 0 then o += gp_lat(i) + " "
        next
        o += lb
        o += "A flat distribution with every rune present suggests a polyalphabetic" + lb
        o += "or running key; gaps suggest a restricted or short text." + lb
    end if

    return o

end function

function cic_bigram_stats(src() as long, byval l as integer) as string

    gp_init()

    dim as integer r(l + 1)
    dim as integer n = 0
    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            n += 1
            r(n) = v
        end if
    next

    if n < 3 then return "Error: too few runes for bigram statistics."

    dim as integer bg(0 to GP_COUNT-1, 0 to GP_COUNT-1)
    dim as integer doublets = 0
    for i as integer = 1 to n-1
        bg(r(i), r(i+1)) += 1
        if r(i) = r(i+1) then doublets += 1
    next

    dim as integer total = n - 1
    dim as double expected_dbl = cdbl(total) / GP_COUNT

    dim as string o = "Bigrams and doublets" + lb
    o += "Runes: " + str(n) + "   bigrams: " + str(total) + lb + lb

    o += "Doublets (a rune immediately repeated): " + str(doublets) + lb
    o += "Expected under a flat random model:     " + str(cint(expected_dbl)) + lb
    if expected_dbl > 0 then
        dim as double ratio = doublets / expected_dbl
        o += "Ratio: " + left(str(ratio) + "000", 5) + lb + lb
        if ratio < 0.55 then
            o += "Markedly few doublets. Some Liber Primus hypotheses predict this:" + lb
            o += "a key stream that never repeats a value at adjacent positions, or" + lb
            o += "a cipher that forbids fixed points, both suppress them." + lb
        elseif ratio > 1.6 then
            o += "Markedly many doublets. Consistent with plaintext-like structure" + lb
            o += "or a key stream with long runs of a constant value." + lb
        else
            o += "Close to random expectation. No signal either way." + lb
        end if
    end if

    o += lb + "Most frequent bigrams:" + lb
    for rank as integer = 1 to 15
        dim as integer bi = -1, bj = -1, bv = 0
        for i as integer = 0 to GP_COUNT-1
            for j as integer = 0 to GP_COUNT-1
                if bg(i,j) > bv then bv = bg(i,j) : bi = i : bj = j
            next
        next
        if bi < 0 then exit for
        o += "  " + cic_pad(gp_lat(bi) + gp_lat(bj), 10) + cic_lpad(str(bv), 5) + lb
        bg(bi,bj) = 0
    next

    return o

end function

function cic_gematria_words(src() as long, byval l as integer) as string

    gp_init()

    dim as string o = "Gematria by word" + lb + lb
    o += "  word                     runes    sum   prime" + lb

    dim as longint total = 0
    dim as integer nwords = 0, nprime = 0
    dim as integer i = 1

    while i <= l
        while i <= l andalso (src(i) < 1 orelse src(i) > GP_COUNT)
            i += 1
        wend
        if i > l then exit while

        dim as longint wsum = 0
        dim as integer wlen = 0
        dim as string wlat = ""
        while i <= l andalso src(i) >= 1 andalso src(i) <= GP_COUNT
            dim as integer v = src(i) - 1
            wsum += gp_prime(v)
            wlat += gp_lat(v)
            wlen += 1
            i += 1
        wend

        nwords += 1
        total += wsum
        dim as string pf = ""
        if is_prime(wsum) then
            pf = "prime"
            nprime += 1
        end if

        if nwords <= 400 then
            o += "  " + cic_pad(lcase(wlat), 24) + cic_lpad(str(wlen), 5) + _
                 cic_lpad(str(wsum), 7) + "   " + pf + lb
        end if
    wend

    if nwords = 0 then return "Error: no runic symbols (1..29) in the input."
    if nwords > 400 then o += "  ... (" + str(nwords - 400) + " more words not listed)" + lb

    o += lb
    o += "Words: " + str(nwords) + lb
    o += "Words with a prime sum: " + str(nprime)
    if nwords > 0 then
        o += "  (" + left(str(100.0 * nprime / nwords) + "000", 5) + "%)"
    end if
    o += lb
    o += "Expected by chance near this magnitude: roughly 1 in ln(sum), so a" + lb
    o += "markedly higher rate is the interesting result, not a high raw count." + lb + lb
    o += "Total gematria sum: " + str(total) + lb
    if is_prime(total) then
        o += "The total is prime." + lb
    else
        o += "The total is not prime. Totient: " + str(totient(total)) + lb
    end if

    return o

end function

function cic_totient_chain(byval n as longint) as string

    if n < 1 then return "Error: totient chain needs a positive integer."

    dim as string o = "Totient chain from " + str(n) + lb + lb
    dim as integer steps = 0
    dim as longint v = n

    o += "  " + str(v)
    while v > 1 andalso steps < 200
        v = totient(v)
        steps += 1
        o += " -> " + str(v)
        if steps mod 8 = 0 then o += lb + "  "
    wend

    o += lb + lb + "Chain length to 1: " + str(steps) + lb

    if is_prime(n) then
        o += str(n) + " is prime, so the first step is simply n-1." + lb
    else
        o += str(n) + " is composite. Totient: " + str(totient(n)) + lb
    end if

    return o

end function

#endif
