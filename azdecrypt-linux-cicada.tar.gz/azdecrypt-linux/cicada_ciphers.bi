'===============================================================================
' cicada_ciphers.bi - cipher operations specific to Cicada 3301 / Liber Primus
'
' All operations work on the 29-rune Gematria Primus alphabet, represented as
' integers 1..29 in AZdecrypt's info() / cstate() arrays (rune index + 1).
'
' Symbol value 0 is treated as a non-rune (word separator / punctuation) and is
' passed through untouched by every operation here. This matters: Liber Primus
' preserves word boundaries, and shifting them would destroy the structure that
' makes cribs work.
'
' Known-solved pages of Liber Primus used Atbash and Vigenere over the runic
' alphabet, with keys drawn from the text itself ("DIVINITY", "FIRFUMFERENFE").
' The unsolved pages are believed to use a running key or a stream derived from
' primes/totients, which is why those generators are here.
'===============================================================================

#ifndef CICADA_CIPHERS_BI
#define CICADA_CIPHERS_BI

#include once "cicada_gematria.bi"

'-------------------------------------------------------------------------------
' Atbash over the 29-rune alphabet.
'
' rune i -> rune (28 - i).  Self-inverse.
'-------------------------------------------------------------------------------
sub cic_atbash(src() as long, dst() as long, byval l as integer)
    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            dst(i) = (GP_COUNT - 1 - v) + 1
        else
            dst(i) = src(i)          'pass through separators
        end if
    next
end sub

'-------------------------------------------------------------------------------
' Caesar / constant shift over 29 runes.
'
' Positive n shifts forward. Decryption is cic_shift with -n.
'-------------------------------------------------------------------------------
sub cic_shift(src() as long, dst() as long, byval l as integer, byval n as integer)
    dim as integer m = ((n mod GP_COUNT) + GP_COUNT) mod GP_COUNT
    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            dst(i) = ((v + m) mod GP_COUNT) + 1
        else
            dst(i) = src(i)
        end if
    next
end sub

'-------------------------------------------------------------------------------
' Vigenere over 29 runes with an explicit key.
'
' key()   - key stream as rune indices 0..28
' keylen  - number of entries in key()
' decrypt - 0 to encrypt, 1 to decrypt
'
' The key advances only on runes, not on separators. This is the behaviour that
' matches the solved Liber Primus pages: separators do not consume key material.
'-------------------------------------------------------------------------------
sub cic_vigenere(src() as long, dst() as long, byval l as integer, _
                 key() as integer, byval keylen as integer, byval decrypt as integer)

    if keylen < 1 then
        for i as integer = 1 to l : dst(i) = src(i) : next
        return
    end if

    dim as integer kp = 0

    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            dim as integer k = key(kp mod keylen) mod GP_COUNT
            if k < 0 then k += GP_COUNT
            dim as integer r
            if decrypt then
                r = ((v - k) mod GP_COUNT + GP_COUNT) mod GP_COUNT
            else
                r = (v + k) mod GP_COUNT
            end if
            dst(i) = r + 1
            kp += 1
        else
            dst(i) = src(i)
        end if
    next

end sub

'Convenience: build a key array from a Latin key string ("DIVINITY").
'Returns key length, or 0 if the string contained no valid runes.
function cic_key_from_latin(byref s as string, key() as integer) as integer

    gp_init()
    dim as string runes = gp_latin_to_runes(s)
    dim as integer n = 0
    dim as integer i = 1

    while i <= len(runes)
        dim as integer sl = utf8_seqlen(runes, i)
        if sl = 0 then exit while
        dim as integer idx = gp_index_of_rune(mid(runes, i, sl))
        if idx >= 0 then
            key(n) = idx
            n += 1
        end if
        i += sl
    wend

    return n

end function

'-------------------------------------------------------------------------------
' Key stream generators
'
' These fill key() with rune indices 0..28 and return the count.
'-------------------------------------------------------------------------------

'Sequential primes, reduced mod 29.
'  skip  - how many primes to skip before starting (0 = start at 2)
'  n     - how many entries to generate
function cic_key_primes(key() as integer, byval n as integer, byval skip as integer = 0) as integer
    for i as integer = 0 to n-1
        dim as longint p = prime_nth(i + 1 + skip)
        key(i) = cint(p mod GP_COUNT)
    next
    return n
end function

'Totients of the sequential integers, reduced mod 29.
function cic_key_totient(key() as integer, byval n as integer, byval start as integer = 1) as integer
    for i as integer = 0 to n-1
        key(i) = cint(totient(start + i) mod GP_COUNT)
    next
    return n
end function

'Totients of sequential primes, reduced mod 29.
'For a prime p, totient(p) = p-1, so this is (prime_nth(i)-1) mod 29.
function cic_key_totient_primes(key() as integer, byval n as integer, byval skip as integer = 0) as integer
    for i as integer = 0 to n-1
        dim as longint p = prime_nth(i + 1 + skip)
        key(i) = cint((p - 1) mod GP_COUNT)
    next
    return n
end function

'Fibonacci sequence mod 29.
function cic_key_fibonacci(key() as integer, byval n as integer) as integer
    dim as longint a = 0, b = 1
    for i as integer = 0 to n-1
        key(i) = cint(a mod GP_COUNT)
        dim as longint t = (a + b) mod 1000000007
        a = b
        b = t
    next
    return n
end function

'-------------------------------------------------------------------------------
' Running-key Vigenere: the key is the plaintext of another passage, or the
' cipher itself offset by some amount. Widely suspected for the unsolved pages.
'
' offset - how far into src() the key stream starts
'-------------------------------------------------------------------------------
sub cic_runningkey(src() as long, dst() as long, byval l as integer, _
                   keysrc() as long, byval keylen as integer, _
                   byval offset as integer, byval decrypt as integer)

    dim as integer kp = offset

    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            'Advance past non-runes in the key source.
            dim as integer guard = 0
            dim as integer k = -1
            while guard < keylen * 2
                if kp >= keylen then kp = 0
                dim as integer kv = keysrc(kp + 1) - 1
                kp += 1
                if kv >= 0 andalso kv < GP_COUNT then
                    k = kv
                    exit while
                end if
                guard += 1
            wend
            if k < 0 then k = 0

            dim as integer r
            if decrypt then
                r = ((v - k) mod GP_COUNT + GP_COUNT) mod GP_COUNT
            else
                r = (v + k) mod GP_COUNT
            end if
            dst(i) = r + 1
        else
            dst(i) = src(i)
        end if
    next

end sub

'-------------------------------------------------------------------------------
' Prime-indexed shift: the shift applied to rune position i is derived from the
' i-th prime. Distinct from a Vigenere with a prime key because the index runs
' over rune positions rather than cycling a fixed-length key.
'
' mode 0: shift by prime_nth(i) mod 29
' mode 1: shift by (prime_nth(i)-1) mod 29    (totient of the prime)
'-------------------------------------------------------------------------------
sub cic_prime_shift(src() as long, dst() as long, byval l as integer, _
                    byval mode as integer, byval decrypt as integer)

    dim as integer ri = 0

    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            ri += 1
            dim as longint p = prime_nth(ri)
            dim as integer k
            if mode = 1 then
                k = cint((p - 1) mod GP_COUNT)
            else
                k = cint(p mod GP_COUNT)
            end if
            dim as integer r
            if decrypt then
                r = ((v - k) mod GP_COUNT + GP_COUNT) mod GP_COUNT
            else
                r = (v + k) mod GP_COUNT
            end if
            dst(i) = r + 1
        else
            dst(i) = src(i)
        end if
    next

end sub

'-------------------------------------------------------------------------------
' Gematria sum
'
' Adds the prime values of every rune in the text. Cicada used these sums as
' checksums and as pointers, so it is worth having as a readout.
'-------------------------------------------------------------------------------
function cic_gematria_sum(src() as long, byval l as integer) as longint
    gp_init()
    dim as longint total = 0
    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then total += gp_prime(v)
    next
    return total
end function

'-------------------------------------------------------------------------------
' Index of coincidence for the 29-rune alphabet.
'
' Random runic text gives ~1/29 = 0.0345. English-like plaintext transliterated
' into futhorc runs noticeably higher, around 0.05-0.07 depending on the passage.
' Useful for spotting whether a candidate decryption is structured at all.
'-------------------------------------------------------------------------------
function cic_ioc(src() as long, byval l as integer) as double

    dim as integer f(0 to GP_COUNT-1)
    dim as integer n = 0

    for i as integer = 1 to l
        dim as integer v = src(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            f(v) += 1
            n += 1
        end if
    next

    if n < 2 then return 0.0

    dim as double num = 0.0
    for i as integer = 0 to GP_COUNT-1
        num += cdbl(f(i)) * cdbl(f(i) - 1)
    next

    return num / (cdbl(n) * cdbl(n - 1))

end function

#endif
