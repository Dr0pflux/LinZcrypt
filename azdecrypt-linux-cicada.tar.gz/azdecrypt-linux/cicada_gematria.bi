'cicada_gematria.bi - Gematria Primus alphabet and runic transcoding

#ifndef CICADA_GEMATRIA_BI
#define CICADA_GEMATRIA_BI

const GP_COUNT = 29          'number of runes in Gematria Primus

'The table.
dim shared as string gp_rune(0 to GP_COUNT-1)
dim shared as string gp_latin(0 to GP_COUNT-1)
dim shared as string gp_latin_alt(0 to GP_COUNT-1)
dim shared as integer gp_prime(0 to GP_COUNT-1)

'U/V, C/K, S/Z, NG/ING, IA/IO each have two readings. 1 = V,K,Z,ING,IO.
dim shared as integer gp_alt_forms = 1

dim shared as integer gp_ready = 0

sub gp_init()

    if gp_ready then return

    'idx   rune bytes            latin  prime   Unicode name
    gp_rune(0)  = chr(&hE1)+chr(&h9A)+chr(&hA0) : gp_latin(0)  = "F"   : gp_prime(0)  = 2     'U+16A0 RUNIC LETTER FEHU FEOH FE F
    gp_rune(1)  = chr(&hE1)+chr(&h9A)+chr(&hA2) : gp_latin(1)  = "U"   : gp_prime(1)  = 3     'U+16A2 RUNIC LETTER URUZ UR U
    gp_rune(2)  = chr(&hE1)+chr(&h9A)+chr(&hA6) : gp_latin(2)  = "TH"  : gp_prime(2)  = 5     'U+16A6 RUNIC LETTER THURISAZ THURS THORN
    gp_rune(3)  = chr(&hE1)+chr(&h9A)+chr(&hA9) : gp_latin(3)  = "O"   : gp_prime(3)  = 7     'U+16A9 RUNIC LETTER OS O
    gp_rune(4)  = chr(&hE1)+chr(&h9A)+chr(&hB1) : gp_latin(4)  = "R"   : gp_prime(4)  = 11    'U+16B1 RUNIC LETTER RAIDO RAD REID R
    gp_rune(5)  = chr(&hE1)+chr(&h9A)+chr(&hB3) : gp_latin(5)  = "C"   : gp_prime(5)  = 13    'U+16B3 RUNIC LETTER CEN
    gp_rune(6)  = chr(&hE1)+chr(&h9A)+chr(&hB7) : gp_latin(6)  = "G"   : gp_prime(6)  = 17    'U+16B7 RUNIC LETTER GEBO GYFU G
    gp_rune(7)  = chr(&hE1)+chr(&h9A)+chr(&hB9) : gp_latin(7)  = "W"   : gp_prime(7)  = 19    'U+16B9 RUNIC LETTER WUNJO WYNN W
    gp_rune(8)  = chr(&hE1)+chr(&h9A)+chr(&hBB) : gp_latin(8)  = "H"   : gp_prime(8)  = 23    'U+16BB RUNIC LETTER HAEGL H
    gp_rune(9)  = chr(&hE1)+chr(&h9A)+chr(&hBE) : gp_latin(9)  = "N"   : gp_prime(9)  = 29    'U+16BE RUNIC LETTER NAUDIZ NYD NAUD N
    gp_rune(10) = chr(&hE1)+chr(&h9B)+chr(&h81) : gp_latin(10) = "I"   : gp_prime(10) = 31    'U+16C1 RUNIC LETTER ISAZ IS ISS I
    gp_rune(11) = chr(&hE1)+chr(&h9B)+chr(&h84) : gp_latin(11) = "J"   : gp_prime(11) = 37    'U+16C4 RUNIC LETTER GER
    gp_rune(12) = chr(&hE1)+chr(&h9B)+chr(&h87) : gp_latin(12) = "EO"  : gp_prime(12) = 41    'U+16C7 RUNIC LETTER IWAZ EOH
    gp_rune(13) = chr(&hE1)+chr(&h9B)+chr(&h88) : gp_latin(13) = "P"   : gp_prime(13) = 43    'U+16C8 RUNIC LETTER PERTHO PEORTH P
    gp_rune(14) = chr(&hE1)+chr(&h9B)+chr(&h89) : gp_latin(14) = "X"   : gp_prime(14) = 47    'U+16C9 RUNIC LETTER ALGIZ EOLHX
    gp_rune(15) = chr(&hE1)+chr(&h9B)+chr(&h8A) : gp_latin(15) = "S"   : gp_prime(15) = 53    'U+16CA RUNIC LETTER SOWILO S
    gp_rune(16) = chr(&hE1)+chr(&h9B)+chr(&h8F) : gp_latin(16) = "T"   : gp_prime(16) = 59    'U+16CF RUNIC LETTER TIWAZ TIR TYR T
    gp_rune(17) = chr(&hE1)+chr(&h9B)+chr(&h92) : gp_latin(17) = "B"   : gp_prime(17) = 61    'U+16D2 RUNIC LETTER BERKANAN BEORC BJARKAN B
    gp_rune(18) = chr(&hE1)+chr(&h9B)+chr(&h96) : gp_latin(18) = "E"   : gp_prime(18) = 67    'U+16D6 RUNIC LETTER EHWAZ EH E
    gp_rune(19) = chr(&hE1)+chr(&h9B)+chr(&h97) : gp_latin(19) = "M"   : gp_prime(19) = 71    'U+16D7 RUNIC LETTER MANNAZ MAN M
    gp_rune(20) = chr(&hE1)+chr(&h9B)+chr(&h9A) : gp_latin(20) = "L"   : gp_prime(20) = 73    'U+16DA RUNIC LETTER LAUKAZ LAGU LOGR L
    gp_rune(21) = chr(&hE1)+chr(&h9B)+chr(&h9D) : gp_latin(21) = "NG"  : gp_prime(21) = 79    'U+16DD RUNIC LETTER ING
    gp_rune(22) = chr(&hE1)+chr(&h9B)+chr(&h9F) : gp_latin(22) = "OE"  : gp_prime(22) = 83    'U+16DF RUNIC LETTER OTHALAN ETHEL O
    gp_rune(23) = chr(&hE1)+chr(&h9B)+chr(&h9E) : gp_latin(23) = "D"   : gp_prime(23) = 89    'U+16DE RUNIC LETTER DAGAZ DAEG D
    gp_rune(24) = chr(&hE1)+chr(&h9A)+chr(&hAA) : gp_latin(24) = "A"   : gp_prime(24) = 97    'U+16AA RUNIC LETTER AC A
    gp_rune(25) = chr(&hE1)+chr(&h9A)+chr(&hAB) : gp_latin(25) = "AE"  : gp_prime(25) = 101   'U+16AB RUNIC LETTER AESC
    gp_rune(26) = chr(&hE1)+chr(&h9A)+chr(&hA3) : gp_latin(26) = "Y"   : gp_prime(26) = 103   'U+16A3 RUNIC LETTER YR
    gp_rune(27) = chr(&hE1)+chr(&h9B)+chr(&hA1) : gp_latin(27) = "IA"  : gp_prime(27) = 107   'U+16E1 RUNIC LETTER IOR
    gp_rune(28) = chr(&hE1)+chr(&h9B)+chr(&hA0) : gp_latin(28) = "EA"  : gp_prime(28) = 109   'U+16E0 RUNIC LETTER EAR

    'both forms are attested
    for i as integer = 0 to GP_COUNT-1
        gp_latin_alt(i) = gp_latin(i)
    next
    gp_latin_alt(1)  = "V"     'U/V
    gp_latin_alt(5)  = "K"     'C/K
    gp_latin_alt(15) = "Z"     'S/Z
    gp_latin_alt(21) = "ING"   'NG/ING
    gp_latin_alt(27) = "IO"    'IA/IO

    gp_ready = 1

end sub

'Lookups

'Stats symbol display: 0=character 1=rune 2=number
dim shared as integer gp_display = 0

function gp_symbol(byval v as integer) as string
    if gp_display = 2 then return str(v)
    if gp_display = 1 then
        if v >= 1 andalso v <= GP_COUNT then
            gp_init()
            return gp_rune(v - 1)
        end if
        return str(v)
    end if
    if v >= 32 andalso v < 127 then return chr(v)
    return str(v)
end function

function gp_lat(byval i as integer) as string
    if i < 0 orelse i >= GP_COUNT then return "?"
    if gp_alt_forms then return gp_latin_alt(i)
    return gp_latin(i)
end function

'Rune (UTF-8 string) -> index 0..28, or -1 if not a Gematria Primus rune.
function gp_index_of_rune(byref r as string) as integer
    gp_init()
    for i as integer = 0 to GP_COUNT-1
        if gp_rune(i) = r then return i
    next
    return -1
end function

'Latin transliteration -> index 0..28, or -1.
function gp_index_of_latin(byref s as string) as integer
    gp_init()
    dim as string u = ucase(s)
    for i as integer = 0 to GP_COUNT-1
        if gp_latin(i) = u then return i
    next
    'Accept the alternate readings too, so V/K/Z/ING/IO encode correctly.
    for i as integer = 0 to GP_COUNT-1
        if gp_latin_alt(i) = u then return i
    next
    return -1
end function

'Prime -> index 0..28, or -1.
function gp_index_of_prime(byval p as integer) as integer
    gp_init()
    for i as integer = 0 to GP_COUNT-1
        if gp_prime(i) = p then return i
    next
    return -1
end function

'UTF-8 helpers

'Length in bytes of the UTF-8 sequence starting at byte position p (1-based).
function utf8_seqlen(byref s as string, byval p as integer) as integer
    if p < 1 orelse p > len(s) then return 0
    dim as ubyte b = asc(s, p)
    if b < &h80 then return 1
    if (b and &hE0) = &hC0 then return 2
    if (b and &hF0) = &hE0 then return 3
    if (b and &hF8) = &hF0 then return 4
    return 1   'invalid lead byte - consume one and move on
end function

'Transcoding: runes <-> AZdecrypt numeric symbols

'Runic text -> space-separated numbers suitable for AZdecrypt's numeric input.
function gp_runes_to_numbers(byref s as string, byval keep_punct as integer = 0) as string

    gp_init()
    dim as string o
    dim as integer i = 1

    while i <= len(s)
        dim as integer n = utf8_seqlen(s, i)
        if n = 0 then exit while
        dim as string ch = mid(s, i, n)
        dim as integer idx = gp_index_of_rune(ch)
        if idx >= 0 then
            if len(o) then o += " "
            o += str(idx + 1)
        elseif keep_punct then
            'Word/section separators in Liber Primus are '-' and '.'
            if ch = "-" orelse ch = "." then
                if len(o) then o += " "
                o += "0"
            end if
        end if
        i += n
    wend

    return o

end function

'Numbers -> runes.
function gp_numbers_to_runes(nums() as long, byval l as integer) as string
    gp_init()
    dim as string o
    for i as integer = 1 to l
        dim as integer v = nums(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            o += gp_rune(v)
        else
            o += "?"
        end if
    next
    return o
end function

'Numbers -> Latin transliteration.
function gp_numbers_to_latin(nums() as long, byval l as integer) as string
    gp_init()
    dim as string o
    for i as integer = 1 to l
        dim as integer v = nums(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            o += gp_lat(v)
        else
            o += "?"
        end if
    next
    return o
end function

'Runic text -> Latin transliteration (direct, no numeric round trip).
function gp_runes_to_latin(byref s as string) as string

    gp_init()
    dim as string o
    dim as integer i = 1

    while i <= len(s)
        dim as integer n = utf8_seqlen(s, i)
        if n = 0 then exit while
        dim as string ch = mid(s, i, n)
        dim as integer idx = gp_index_of_rune(ch)
        if idx >= 0 then
            o += gp_lat(idx)
        else
            'Preserve punctuation and layout so the shape of the text survives.
            o += ch
        end if
        i += n
    wend

    return o

end function

'Latin text -> runes. Greedy longest-match so digraphs bind before singles.
function gp_latin_to_runes(byref s as string) as string

    gp_init()
    dim as string u = ucase(s)
    dim as string o
    dim as integer i = 1

    while i <= len(u)
        dim as integer matched = 0
        'Longest match first: ING is 3 characters, digraphs are 2.
        if i + 2 <= len(u) then
            dim as integer idx3 = gp_index_of_latin(mid(u, i, 3))
            if idx3 >= 0 then
                o += gp_rune(idx3)
                i += 3
                matched = 1
            end if
        end if
        if matched = 0 andalso i + 1 <= len(u) then
            dim as integer idx = gp_index_of_latin(mid(u, i, 2))
            if idx >= 0 then
                o += gp_rune(idx)
                i += 2
                matched = 1
            end if
        end if
        if matched = 0 then
            dim as integer idx = gp_index_of_latin(mid(u, i, 1))
            if idx >= 0 then
                o += gp_rune(idx)
            else
                o += mid(u, i, 1)
            end if
            i += 1
        end if
    wend

    return o

end function

'Number theory used by Cicada ciphers

'The n-th prime, 1-based (prime_nth(1) = 2). Simple sieve-free trial division;
function prime_nth(byval n as integer) as longint
    if n < 1 then return 0
    dim as longint c = 1
    dim as integer found = 0
    while found < n
        c += 1
        dim as integer isp = 1
        dim as longint d = 2
        while d*d <= c
            if c mod d = 0 then
                isp = 0
                exit while
            end if
            d += 1
        wend
        if isp then found += 1
    wend
    return c
end function

'Is n prime?
function is_prime(byval n as longint) as integer
    if n < 2 then return 0
    if n < 4 then return 1
    if n mod 2 = 0 then return 0
    dim as longint d = 3
    while d*d <= n
        if n mod d = 0 then return 0
        d += 2
    wend
    return 1
end function

'Euler's totient of n.
function totient(byval n as longint) as longint
    if n < 1 then return 0
    dim as longint result = n
    dim as longint p = 2
    dim as longint m = n
    while p*p <= m
        if m mod p = 0 then
            while m mod p = 0
                m \= p
            wend
            result -= result \ p
        end if
        p += 1
    wend
    if m > 1 then result -= result \ m
    return result
end function

#endif
