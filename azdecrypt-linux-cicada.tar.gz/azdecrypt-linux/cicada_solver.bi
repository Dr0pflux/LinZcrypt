'cicada_solver.bi - key stream solvers for Cicada 3301 / Liber Primus

#ifndef CICADA_SOLVER_BI
#define CICADA_SOLVER_BI

#include once "cicada_ciphers.bi"

const CICSOLVE_VIGENERE  = 1   'periodic key, scan of lengths
const CICSOLVE_RUNNINGKEY = 2  'free key stream, one value per rune
const CICSOLVE_AUTOKEY   = 3   'primer then plaintext feedback
const CICSOLVE_SCAN      = 4   'enumerate closed-form transforms

dim shared as integer cicsolve_mode = CICSOLVE_VIGENERE
dim shared as integer cicsolve_running = 0
dim shared as integer cicsolve_stop = 0
dim shared as integer cicsolve_minlen = 2
dim shared as integer cicsolve_maxlen = 32
dim shared as integer cicsolve_restarts = 6

dim shared as long    cicsolve_cip(0 to 65535)
dim shared as integer cicsolve_l = 0

dim shared as integer cic_ln(0 to GP_COUNT-1)
dim shared as integer cic_lc(0 to GP_COUNT-1, 0 to 2)
dim shared as integer cic_map_ok = 0
dim shared as string  cic_map_desc

private function cic_letters_ok(byref s as string, byval r as integer) as integer
    if len(s) < 1 orelse len(s) > 3 then return 0
    for j as integer = 1 to len(s)
        dim as integer c = asc(lcase(mid(s, j, 1)))
        dim as integer a = alpharev(c)
        if alphabet(a) <> c then
            c = asc(ucase(mid(s, j, 1)))
            a = alpharev(c)
            if alphabet(a) <> c then return 0
        end if
        cic_lc(r, j-1) = a
    next
    cic_ln(r) = len(s)
    return 1
end function

function cic_build_map() as string

    gp_init()
    cic_map_ok = 0

    if ngram_alphabet_size < 1 then
        return "Error: no n-grams loaded. Load a runeglish n-gram set first" + lb + _
               "(File > Load n-grams). The solver scores candidate plaintext" + lb + _
               "with the same tables the main solver uses, so it needs them."
    end if

    if ngram_alphabet_size = GP_COUNT then
        dim as string missing = ""
        for i as integer = 0 to GP_COUNT-1
            dim as integer c = asc(gp_runeglish(i))
            dim as integer a = alpharev(c)
            if alphabet(a) <> c then
                missing += gp_runeglish(i) + " "
            else
                cic_ln(i) = 1
                cic_lc(i, 0) = a
            end if
        next
        if len(missing) = 0 then
            cic_map_ok = 1
            cic_map_desc = "29-symbol runeglish set, one symbol per rune"
            return "Ok"
        end if
    end if

    dim as string bad = ""
    for i as integer = 0 to GP_COUNT-1
        if cic_letters_ok(gp_latin(i), i) = 0 then
            if cic_letters_ok(gp_latin_alt(i), i) = 0 then
                bad += gp_latin(i) + " "
            end if
        end if
    next

    if len(bad) > 0 then
        return "Error: cannot map runes onto the loaded " + str(ngram_alphabet_size) + _
               "-symbol alphabet." + lb + _
               "No spelling of these runes uses only letters the alphabet has: " + bad + lb + _
               "Load a set built from runeglish text, either 29-symbol (one" + lb + _
               "character per rune) or Latin (digraphs spelled out)."
    end if

    dim as integer expands = 0
    for i as integer = 0 to GP_COUNT-1
        if cic_ln(i) > 1 then expands += 1
    next

    cic_map_ok = 1
    cic_map_desc = str(ngram_alphabet_size) + "-symbol Latin set, " + _
                   str(expands) + " digraph runes spelled out"
    return "Ok"

end function

function cic_score(sol() as ubyte, byval n as integer) as longint

    dim as longint sc = 0
    if n < ngram_size then return 0

    select case ngram_system

        case 1
            select case ngram_size
                case 2
                    for i as integer = 1 to n-1
                        sc += ngp(g2(sol(i),sol(i+1)))
                    next
                case 3
                    for i as integer = 1 to n-2
                        sc += ngp(g3(sol(i),sol(i+1),sol(i+2)))
                    next
                case 4
                    for i as integer = 1 to n-3
                        sc += ngp(g4(sol(i),sol(i+1),sol(i+2),sol(i+3)))
                    next
                case 5
                    for i as integer = 1 to n-4
                        sc += ngp(g5(sol(i),sol(i+1),sol(i+2),sol(i+3),sol(i+4)))
                    next
                case 6
                    for i as integer = 1 to n-5
                        sc += ngp(g6(sol(i),sol(i+1),sol(i+2),sol(i+3),sol(i+4),sol(i+5)))
                    next
                case 7
                    for i as integer = 1 to n-6
                        sc += ngp(g7(sol(i),sol(i+1),sol(i+2),sol(i+3),sol(i+4),sol(i+5),sol(i+6)))
                    next
            end select

        case 2
            select case ngram_size
                case 6
                    for i as integer = 1 to n-5
                        sc += ngp(bh6(h3(sol(i),sol(i+1),sol(i+2)), _
                                      h3(sol(i+3),sol(i+4),sol(i+5))))
                    next
                case 8
                    for i as integer = 1 to n-7
                        sc += ngp(bh8(h4(sol(i),sol(i+1),sol(i+2),sol(i+3)), _
                                      h4(sol(i+4),sol(i+5),sol(i+6),sol(i+7))))
                    next
                case 10
                    for i as integer = 1 to n-9
                        sc += ngp(bh10(h5(sol(i),sol(i+1),sol(i+2),sol(i+3),sol(i+4)), _
                                       h5(sol(i+5),sol(i+6),sol(i+7),sol(i+8),sol(i+9))))
                    next
            end select

    end select

    return sc

end function

dim shared as integer cic_r(0 to 65535)     'rune values 0..28
dim shared as integer cic_rn = 0
dim shared as ubyte   cic_p(0 to 196607)   'expanded plaintext, alphabet indices
dim shared as integer cic_pl(0 to 65535)   'candidate plaintext, rune values
dim shared as integer cic_pn = 0           'expanded length

function cic_score_runes(pl() as integer, byval n as integer) as longint
    dim as integer o = 0
    for i as integer = 1 to n
        dim as integer r = pl(i)
        for j as integer = 0 to cic_ln(r)-1
            o += 1
            cic_p(o) = cic_lc(r, j)
        next
    next
    cic_pn = o
    return cic_score(cic_p(), o)
end function

function cic_score_key(k() as integer, byval klen as integer) as longint
    dim as integer kp = 0
    for i as integer = 1 to cic_rn
        dim as integer v = cic_r(i) - k(kp)
        if v < 0 then v += GP_COUNT
        cic_pl(i) = v
        kp += 1
        if kp >= klen then kp = 0
    next
    return cic_score_runes(cic_pl(), cic_rn)
end function

function cic_score_autokey(k() as integer, byval klen as integer) as longint
    for i as integer = 1 to cic_rn
        dim as integer kv
        if i <= klen then kv = k(i-1) else kv = cic_pl(i - klen)
        dim as integer v = cic_r(i) - kv
        if v < 0 then v += GP_COUNT
        cic_pl(i) = v
    next
    return cic_score_runes(cic_pl(), cic_rn)
end function

function cic_anneal(byval klen as integer, byval iters as integer, _
                    byval restarts as integer, bestkey() as integer, _
                    byval autokey as integer = 0) as longint

    dim as integer k(0 to 1023)
    dim as longint best = -1

    for rs as integer = 1 to restarts

        if cicsolve_stop then exit for

        for i as integer = 0 to klen-1
            k(i) = int(rnd * GP_COUNT)
        next

        dim as longint cur
        if autokey then cur = cic_score_autokey(k(), klen) else cur = cic_score_key(k(), klen)

        dim as double temp = 400.0
        dim as double tstep = temp / iters

        for it as integer = 1 to iters
            if (it and 1023) = 0 andalso cicsolve_stop then exit for

            dim as integer p = int(rnd * klen)
            dim as integer old = k(p)
            dim as integer nv = int(rnd * GP_COUNT)
            if nv = old then nv = (nv + 1) mod GP_COUNT
            k(p) = nv

            dim as longint s2
            if autokey then s2 = cic_score_autokey(k(), klen) else s2 = cic_score_key(k(), klen)

            dim as longint d = s2 - cur
            if d > 0 then
                cur = s2
            elseif temp > 0.0001 andalso rnd < exp(d / temp) then
                cur = s2
            else
                k(p) = old
            end if

            temp -= tstep
            if temp < 0.0 then temp = 0.0
        next

        if cur > best then
            best = cur
            for i as integer = 0 to klen-1
                bestkey(i) = k(i)
            next
        end if

    next

    return best

end function

function cic_anneal_stream(byval iters as integer, bestkey() as integer) as longint

    dim as integer k(0 to 65535)
    for i as integer = 0 to cic_rn
        k(i) = 0
    next

    for i as integer = 1 to cic_rn
        cic_pl(i) = cic_r(i)
    next
    dim as longint cur = cic_score_runes(cic_pl(), cic_rn)

    dim as double temp = 300.0
    dim as double tstep = temp / iters

    for it as integer = 1 to iters

        if (it and 1023) = 0 andalso cicsolve_stop then exit for

        dim as integer p = int(rnd * cic_rn) + 1
        dim as integer old = k(p)
        dim as integer nv = int(rnd * GP_COUNT)
        if nv = old then nv = (nv + 1) mod GP_COUNT

        k(p) = nv
        dim as integer v = cic_r(p) - nv
        if v < 0 then v += GP_COUNT
        dim as integer oldp = cic_pl(p)
        cic_pl(p) = v

        dim as longint s2 = cic_score_runes(cic_pl(), cic_rn)
        dim as longint d = s2 - cur

        if d > 0 then
            cur = s2
        elseif temp > 0.0001 andalso rnd < exp(d / temp) then
            cur = s2
        else
            k(p) = old
            cic_pl(p) = oldp
        end if

        temp -= tstep
        if temp < 0.0 then temp = 0.0

    next

    for i as integer = 1 to cic_rn
        bestkey(i) = k(i)
    next

    return cur

end function

function cic_key_to_latin(k() as integer, byval klen as integer) as string
    gp_init()
    dim as string s = ""
    for i as integer = 0 to klen-1
        dim as integer v = k(i)
        if v >= 0 andalso v < GP_COUNT then s += lcase(gp_lat(v))
    next
    return s
end function

function cic_plain_preview(byval maxn as integer) as string
    gp_init()
    dim as string s = ""
    dim as integer n = cic_rn
    if n > maxn then n = maxn
    for i as integer = 1 to n
        s += lcase(gp_lat(cic_pl(i)))
    next
    if cic_rn > maxn then s += " ..."
    return s
end function

function cic_prepare() as string
    cic_rn = 0
    for i as integer = 1 to cicsolve_l
        dim as integer v = cicsolve_cip(i) - 1
        if v >= 0 andalso v < GP_COUNT then
            cic_rn += 1
            cic_r(cic_rn) = v
        end if
    next
    if cic_rn < 40 then
        return "Error: need at least 40 runes to solve (have " + str(cic_rn) + ")." + lb + _
               "Use Cicada > Runes to numbers on a runic page first."
    end if
    return "Ok"
end function

#endif
