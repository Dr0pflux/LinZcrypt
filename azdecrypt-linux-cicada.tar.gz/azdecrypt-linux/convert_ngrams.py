#!/usr/bin/env python3
"""Convert raw-count n-gram files to the log-scaled format AZdecrypt expects.

AZdecrypt does not read occurrence counts, and it does not expect a separator.
Each record is the n-gram characters immediately followed by a 3-digit log
value, then a newline - the loader advances by exactly ngram_size+3 bytes.

A file of raw counts is misparsed, and so is one with a space before the number:
both shift the digits the loader reads, producing the
"N-gram system log value overflows" warning.

This rescales counts to log space and writes a matching .ini.

    python3 convert_ngrams.py FILE [FILE ...]
    python3 convert_ngrams.py --out-dir DIR FILE

Writes FILE_azd.txt and FILE_azd.ini next to the input unless --out-dir is given.
"""

import argparse
import math
import os
import sys


def read_ngrams(path):
    """Return [(ngram, count)], the n-gram length, and the alphabet."""
    rows = []
    alphabet = set()
    size = None
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) >= 2:
                gram, raw = parts[0], parts[1]
            else:
                # No separator: trailing digits are the value, the rest the n-gram.
                i = len(line)
                while i > 0 and line[i - 1].isdigit():
                    i -= 1
                if i == 0 or i == len(line):
                    continue
                gram, raw = line[:i], line[i:]
            try:
                count = float(raw)
            except ValueError:
                continue
            if count <= 0:
                continue
            if size is None:
                size = len(gram)
            elif len(gram) != size:
                continue
            alphabet.update(gram)
            rows.append((gram, count))
    return rows, size, alphabet


def to_log_scores(rows, ceiling=250):
    """Map counts onto 1..ceiling in log space, preserving relative ranking."""
    counts = [c for _, c in rows]
    lo = math.log(min(counts))
    hi = math.log(max(counts))
    span = hi - lo

    out = []
    for gram, c in rows:
        if span <= 0:
            v = ceiling
        else:
            v = 1 + (math.log(c) - lo) / span * (ceiling - 1)
        out.append((gram, int(round(v))))
    return out


def order_alphabet(alphabet):
    upper = "".join(c for c in map(chr, range(65, 91)) if c in alphabet)
    lower = "".join(c for c in map(chr, range(97, 123)) if c in alphabet)
    digit = "".join(c for c in map(chr, range(48, 58)) if c in alphabet)
    other = "".join(
        chr(c) for c in range(33, 256)
        if chr(c) in alphabet and not (48 <= c <= 57 or 65 <= c <= 90 or 97 <= c <= 122)
    )
    return upper + lower + digit + other


def convert(path, out_dir=None):
    rows, size, alphabet = read_ngrams(path)
    if not rows:
        print(f"  {path}: no usable n-grams found", file=sys.stderr)
        return False
    if not (2 <= size <= 7):
        print(f"  {path}: n-gram size {size} outside AZdecrypt's 2..7 range", file=sys.stderr)
        return False

    scored = to_log_scores(rows)
    scored.sort(key=lambda kv: -kv[1])

    base = os.path.splitext(os.path.basename(path))[0]
    target_dir = out_dir or os.path.dirname(os.path.abspath(path))
    os.makedirs(target_dir, exist_ok=True)
    out_txt = os.path.join(target_dir, base + "_azd.txt")
    out_ini = os.path.join(target_dir, base + "_azd.ini")

    # AZdecrypt reads a fixed-width record: n-gram characters immediately
    # followed by 3 digits, then a newline. bl advances by ngram_size+3, so a
    # separator between them shifts every score by one byte.
    with open(out_txt, "w", encoding="utf-8") as f:
        for gram, v in scored:
            f.write(f"{gram}{v:03d}\n")

    alpha = order_alphabet(alphabet)
    with open(out_ini, "w", encoding="utf-8") as f:
        f.write(f"ngram_size={size}\n")
        f.write("ngram_factor=1\n")
        f.write("entropy_weight=1\n")
        f.write(f"alphabet={alpha}\n")
        f.write("temperature=800\n")
        f.write("items=0\n")

    top = scored[0][1]
    bottom = scored[-1][1]
    print(f"  {os.path.basename(path)}")
    print(f"    {len(scored)} n-grams, size {size}, alphabet {len(alpha)} chars")
    print(f"    scores {bottom}..{top}  ->  {os.path.basename(out_txt)}")
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--out-dir")
    args = ap.parse_args()

    print("Converting to AZdecrypt log format...")
    ok = 0
    for path in args.files:
        if convert(path, args.out_dir):
            ok += 1
    print()
    print(f"Converted {ok}/{len(args.files)} file(s).")
    print("Load the _azd.txt files in AZdecrypt; the .ini beside them is used automatically.")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
