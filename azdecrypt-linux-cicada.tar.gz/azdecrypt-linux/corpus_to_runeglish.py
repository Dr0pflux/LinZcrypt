#!/usr/bin/env python3
"""Convert an English corpus to Liber Primus runeglish.

Each of the 29 Gematria Primus runes gets exactly one character, so the output
is a 1:1 symbol encoding that AZdecrypt and n-gram tooling can consume directly.

    lowercase  f v o r k g w h n i j p x s t b e m l d a y   single runes
    uppercase  T=TH  E=EO  G=NG/ING  O=OE  A=AE  I=IA/IO  X=EA   digraph runes

Letters with no rune fold onto their homophone: c and q become k, u becomes v,
z becomes s.

INPUT may be a plain text file or a .zip containing many of them. Zip members
are processed in sequence into a single output file; .gz members are inflated
automatically and non-text members are reported and skipped.

Usage:
    python3 corpus_to_runeglish.py INPUT OUTPUT
    python3 corpus_to_runeglish.py corpus.zip OUTPUT --workers 16
    python3 corpus_to_runeglish.py corpus.zip OUTPUT --filter subdir/
    python3 corpus_to_runeglish.py INPUT OUTPUT --workers 16
    python3 corpus_to_runeglish.py INPUT OUTPUT --format tokens|joined|ngrams
    python3 corpus_to_runeglish.py INPUT OUTPUT --format ngrams --ngram-size 4

Input is one token per line, or any whitespace-separated text. The file is
split into byte ranges and processed in parallel, so memory stays near constant
regardless of corpus size.
"""

import argparse
import mmap
import os
import sys
import time
import gzip
import zipfile
from collections import Counter
from multiprocessing import Pool

import numpy as np

# Digraphs, longest first so ING binds before NG and TH before T. Each becomes a
# sentinel byte in 0x01..0x0F, which no letter can produce, so a substitution
# can never be re-matched by a later pattern or confused with a real letter.
DIGRAPHS = [
    (b"ING", 1),
    (b"NG", 1),
    (b"TH", 2),
    (b"EO", 3),
    (b"OE", 4),
    (b"AE", 5),
    (b"EA", 6),
    (b"IA", 7),
    (b"IO", 7),
]

SENTINEL_OUT = {
    1: ord("G"),   # NG / ING
    2: ord("T"),   # TH
    3: ord("E"),   # EO
    4: ord("O"),   # OE
    5: ord("A"),   # AE
    6: ord("X"),   # EA
    7: ord("I"),   # IA / IO
}

SINGLES = {
    "a": "a", "b": "b", "c": "k", "d": "d", "e": "e", "f": "f", "g": "g",
    "h": "h", "i": "i", "j": "j", "k": "k", "l": "l", "m": "m", "n": "n",
    "o": "o", "p": "p", "q": "k", "r": "r", "s": "s", "t": "t", "u": "v",
    "v": "v", "w": "w", "x": "x", "y": "y", "z": "s",
}


def build_table():
    """One 256-byte lookup covering case folding, homophones and sentinels.

    Unmapped bytes become 0 and are dropped, which removes digits, punctuation
    and whitespace in the same pass.
    """
    tbl = np.zeros(256, dtype=np.uint8)
    for src, dst in SINGLES.items():
        tbl[ord(src)] = ord(dst)
        tbl[ord(src.upper())] = ord(dst)
    for sent, out in SENTINEL_OUT.items():
        tbl[sent] = out
    return tbl


TABLE = build_table()


# Same table but newline survives, so token boundaries are kept in one pass.
TABLE_NL = TABLE.copy()
TABLE_NL[ord("\n")] = ord("\n")


def encode_chunk(text: bytes, keep_newlines: bool = False) -> bytes:
    """Encode raw bytes to runeglish.

    The whole buffer is processed at once. Looping per line costs roughly 50x
    more, because each iteration pays Python overhead that dwarfs the actual
    byte work.
    """
    if not text:
        return b""

    upper = text.upper()
    for pat, sent in DIGRAPHS:
        if pat in upper:
            upper = upper.replace(pat, bytes([sent]))

    arr = np.frombuffer(upper, dtype=np.uint8)
    out = (TABLE_NL if keep_newlines else TABLE)[arr]
    return out[out != 0].tobytes()


TEXT_EXTS = (".txt", ".text", ".tok", ".tokens", "")
SKIP_EXTS = (".zip", ".7z", ".rar", ".tar", ".bz2", ".xz", ".pdf", ".epub",
             ".jpg", ".png", ".gif", ".mp3", ".zst")


def zip_members(path, pattern=None):
    """Text members of a zip, largest first so long jobs start early.

    Returns (members, skipped). Plain text and .gz members are accepted; other
    archives and binaries are reported rather than silently dropped.
    """
    items, skipped = [], []
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = info.filename
            if pattern and pattern not in name:
                continue
            ext = os.path.splitext(name)[1].lower()
            if ext == ".gz" or ext in TEXT_EXTS:
                items.append((name, info.file_size))
            elif ext in SKIP_EXTS:
                skipped.append(name)
            else:
                # Unknown extension: take it, corpora often use odd suffixes.
                items.append((name, info.file_size))
    items.sort(key=lambda kv: -kv[1])
    return items, skipped


def zip_worker(job):
    """Encode one whole zip member. Members are the unit of parallelism, since
    a deflate stream cannot be split at arbitrary byte offsets."""
    path, name, mode, ngram_size = job
    with zipfile.ZipFile(path) as z:
        raw = z.read(name)
    if name.lower().endswith(".gz"):
        try:
            raw = gzip.decompress(raw)
        except OSError:
            return encode_payload(b"", mode, ngram_size)
    return encode_payload(raw, mode, ngram_size)


def find_split_points(path, n):
    """Split the file into n ranges aligned to line boundaries."""
    size = os.path.getsize(path)
    if size == 0:
        return []
    step = max(1, size // n)
    points = [0]
    with open(path, "rb") as f:
        for i in range(1, n):
            f.seek(min(i * step, size))
            f.readline()
            pos = f.tell()
            if points[-1] < pos < size:
                points.append(pos)
    points.append(size)
    return list(zip(points[:-1], points[1:]))


def worker(job):
    path, start, end, mode, ngram_size = job
    with open(path, "rb") as f:
        with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            raw = mm[start:end]
    return encode_payload(raw, mode, ngram_size)


def encode_payload(raw, mode, ngram_size):
    if mode == "joined":
        return encode_chunk(raw)

    if mode == "tokens":
        enc = encode_chunk(raw, keep_newlines=True)
        # Collapse runs of newlines left by blank or fully-stripped lines.
        while b"\n\n" in enc:
            enc = enc.replace(b"\n\n", b"\n")
        if enc.startswith(b"\n"):
            enc = enc[1:]
        if enc and not enc.endswith(b"\n"):
            enc += b"\n"
        return enc

    if mode == "ngrams":
        joined = encode_chunk(raw)
        n = ngram_size
        if len(joined) < n:
            return Counter()
        arr = np.frombuffer(joined, dtype=np.uint8)
        # Stack n shifted views so every column is one n-gram, then count.
        cols = np.stack([arr[i:len(arr) - n + 1 + i] for i in range(n)], axis=1)
        view = np.ascontiguousarray(cols).view(np.dtype((np.void, n)))
        uniq, counts = np.unique(view, return_counts=True)
        return Counter(dict(zip((u.tobytes() for u in uniq), counts.tolist())))

    raise ValueError(mode)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--workers", type=int, default=os.cpu_count())
    ap.add_argument("--format", choices=["tokens", "joined", "ngrams"],
                    default="tokens",
                    help="tokens: one per line (default). "
                         "joined: continuous stream. "
                         "ngrams: frequency-counted n-gram list.")
    ap.add_argument("--ngram-size", type=int, default=4)
    ap.add_argument("--chunks-per-worker", type=int, default=4)
    ap.add_argument("--filter", help="only process zip members whose name contains this")
    args = ap.parse_args()

    if not os.path.exists(args.input):
        print(f"error: {args.input} not found", file=sys.stderr)
        return 1

    size = os.path.getsize(args.input)
    is_zip = zipfile.is_zipfile(args.input)
    looks_zip = args.input.lower().endswith((".zip", ".zipx"))

    # Encoding a zip container as if it were text produces filename fragments in
    # noise, so refuse rather than fall through to the flat-file path.
    if looks_zip and not is_zip:
        print(f"error: {args.input} has a .zip name but is not a readable zip.",
              file=sys.stderr)
        print("       It may be split, encrypted, or a different archive format.",
              file=sys.stderr)
        print("       Extract it first, then point this script at the directory",
              file=sys.stderr)
        print("       contents or a concatenated .txt.", file=sys.stderr)
        return 1

    if not is_zip:
        with open(args.input, "rb") as f:
            magic = f.read(4)
        if magic[:2] in (b"PK", b"\x1f\x8b") or magic[:4] == b"\xfd7zX":
            print(f"error: {args.input} looks like an archive, not text.",
                  file=sys.stderr)
            print("       Extract it first, or pass the .zip directly if it is one.",
                  file=sys.stderr)
            return 1

    if is_zip:
        members, skipped = zip_members(args.input, args.filter)
        if not members:
            print("error: no text members found in the zip", file=sys.stderr)
            return 1
        uncompressed = sum(sz for _, sz in members)
        jobs = [(args.input, name, args.format, args.ngram_size)
                for name, _ in members]
        run = zip_worker
        print(f"input   : {args.input}  ({size / 1e9:.2f} GB compressed)")
        print(f"members : {len(members)}  ({uncompressed / 1e9:.2f} GB uncompressed)")
        if skipped:
            print(f"skipped : {len(skipped)} non-text members "
                  f"(e.g. {', '.join(skipped[:3])})")
    else:
        ranges = find_split_points(args.input,
                                   max(1, args.workers * args.chunks_per_worker))
        if not ranges:
            print("error: input is empty", file=sys.stderr)
            return 1
        jobs = [(args.input, s, e, args.format, args.ngram_size) for s, e in ranges]
        run = worker
        print(f"input   : {args.input}  ({size / 1e9:.2f} GB)")
        print(f"chunks  : {len(ranges)}")

    print(f"workers : {args.workers}")
    print(f"format  : {args.format}")
    print()
    t0 = time.time()

    with Pool(args.workers) as pool:
        if args.format == "ngrams":
            total = Counter()
            for part in pool.imap_unordered(run, jobs):
                total.update(part)
            with open(args.output, "wb") as out:
                for gram, count in total.most_common():
                    out.write(gram + b" " + str(count).encode() + b"\n")
            written = len(total)
        else:
            written = 0
            with open(args.output, "wb") as out:
                for part in pool.imap(run, jobs):
                    out.write(part)
                    written += len(part)

    dt = time.time() - t0
    rate = (size / 1e6) / dt if dt > 0 else 0
    print(f"done in {dt:.1f}s  ({rate:.0f} MB/s)")
    if args.format == "ngrams":
        print(f"{written} distinct {args.ngram_size}-grams -> {args.output}")
    else:
        print(f"{written / 1e6:.1f} MB written -> {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
