'===============================================================================
' gtk_backend.bi - GTK3 backend for AZdecrypt on Linux
'
' Provides the primitives that ui_specific.bi's __fb_linux__ branches call.
' Bridges GTK's push/signal model to the app's pull/message-pump model.
'
' Design: GTK signal handlers push synthetic MSG records onto a ring buffer.
' gtkbe_getmessage() drains it. The app's main loop is otherwise unchanged.
'===============================================================================

#ifdef __fb_linux__

'Select the GTK3 binding. gtk/gtk.bi defaults to GTK2 unless this is set.
#define __USE_GTK3__
#include once "gtk/gtk3.bi"

'-------------------------------------------------------------------------------
' Win32 message constants the app checks against.
' Values are arbitrary but must be distinct and must match app expectations.
'-------------------------------------------------------------------------------
#undef WM_COMMAND
#undef WM_KEYUP
#undef WM_LBUTTONDOWN
#undef WM_RBUTTONDOWN
#undef WM_SETICON
#undef EM_SETSEL

const WM_NULL        = &h0000
const WM_COMMAND     = &h0111
const WM_KEYUP       = &h0101
const WM_LBUTTONDOWN = &h0201
const WM_RBUTTONDOWN = &h0204
const WM_SETICON     = &h0080
const EM_SETSEL      = &h00B1
const WM_CLOSE       = &h0010

const VK_A       = &h41
const VK_CONTROL = &h11

const SW_SHOWNORMAL = 1

'-------------------------------------------------------------------------------
' MSG structure mirroring the Win32 layout the app reads.
' App uses: msg.message, msg.wparam, msg.hwnd, msg.w
'-------------------------------------------------------------------------------
type MSG_TYPE
    hwnd    as any ptr
    message as ulong
    wparam  as long
    lparam  as long
    w       as long      'app references msg.w in 3 places
    time    as ulong
end type

'-------------------------------------------------------------------------------
' Message ring buffer
'-------------------------------------------------------------------------------
const MSGQ_SIZE = 2048

dim shared as MSG_TYPE  msgq(0 to MSGQ_SIZE-1)
dim shared as integer   msgq_head = 0    'next slot to write
dim shared as integer   msgq_tail = 0    'next slot to read
dim shared as any ptr   msgq_mutex

sub msgq_init()
    msgq_mutex = mutexcreate()
    msgq_head = 0
    msgq_tail = 0
end sub

'Push a message. Called from GTK signal handlers (main thread).
sub msgq_push(byval h as any ptr, byval m as ulong, _
              byval wp as long = 0, byval lp as long = 0)
    if msgq_mutex then mutexlock(msgq_mutex)
    dim as integer nxt = (msgq_head + 1) mod MSGQ_SIZE
    if nxt <> msgq_tail then   'drop on overflow rather than corrupt
        msgq(msgq_head).hwnd    = h
        msgq(msgq_head).message = m
        msgq(msgq_head).wparam  = wp
        msgq(msgq_head).lparam  = lp
        msgq(msgq_head).w       = wp
        msgq_head = nxt
    end if
    if msgq_mutex then mutexunlock(msgq_mutex)
end sub

'Pop a message. Returns 0 if queue empty.
function msgq_pop(byref out as MSG_TYPE) as long
    dim as long got = 0
    if msgq_mutex then mutexlock(msgq_mutex)
    if msgq_tail <> msgq_head then
        out = msgq(msgq_tail)
        msgq_tail = (msgq_tail + 1) mod MSGQ_SIZE
        got = 1
    end if
    if msgq_mutex then mutexunlock(msgq_mutex)
    return got
end function

'-------------------------------------------------------------------------------
' Window registry
'
' Each app "window" is a GtkWindow with a GtkFixed inside, because the app
' positions every control with absolute x/y/w/h coordinates (Win32 style).
' GtkFixed is the only GTK container that honours that directly.
'-------------------------------------------------------------------------------
const MAXWIN = 64

type WINREC
    win        as GtkWidget ptr    'the GtkWindow
    fixed      as GtkWidget ptr    'GtkFixed holding absolutely-positioned children
    vbox       as GtkWidget ptr    'vertical box: menubar on top, fixed below
    menubar    as GtkWidget ptr
    accel      as GtkAccelGroup ptr
    close_flag as long             'set by delete-event, read by window_event_close
    in_use     as long
end type

dim shared as WINREC winreg(0 to MAXWIN-1)
dim shared as integer winreg_n = 0

function winreg_find(byval w as any ptr) as integer
    for i as integer = 0 to winreg_n-1
        if winreg(i).in_use andalso cast(any ptr, winreg(i).win) = w then return i
    next
    return -1
end function

'-------------------------------------------------------------------------------
' Radio button grouping
'
' Win32 groups radio buttons implicitly by WS_GROUP and creation order.
' GTK requires an explicit group pointer. We track the most recently created
' radio button per parent window and chain new ones onto it. The app creates
' each radio set consecutively into the same parent, so this reproduces the
' intended grouping.
'-------------------------------------------------------------------------------
const MAXRGRP = 64
type RGRPREC
    parent as GtkWidget ptr
    last   as GtkWidget ptr
    in_use as long
end type
dim shared as RGRPREC rgrp(0 to MAXRGRP-1)
dim shared as integer rgrp_n = 0

function rgrp_last_for(byval parent as GtkWidget ptr) as GtkWidget ptr
    for i as integer = 0 to rgrp_n-1
        if rgrp(i).in_use andalso rgrp(i).parent = parent then return rgrp(i).last
    next
    return NULL
end function

sub rgrp_set_last(byval parent as GtkWidget ptr, byval btn as GtkWidget ptr)
    for i as integer = 0 to rgrp_n-1
        if rgrp(i).in_use andalso rgrp(i).parent = parent then
            rgrp(i).last = btn
            return
        end if
    next
    if rgrp_n < MAXRGRP then
        rgrp(rgrp_n).parent = parent
        rgrp(rgrp_n).last   = btn
        rgrp(rgrp_n).in_use = 1
        rgrp_n += 1
    end if
end sub

'Break the radio chain for a window - call before creating a new radio set.
sub rgrp_break(byval parent as GtkWidget ptr)
    for i as integer = 0 to rgrp_n-1
        if rgrp(i).in_use andalso rgrp(i).parent = parent then
            rgrp(i).last = NULL
            return
        end if
    next
end sub

'-------------------------------------------------------------------------------
' Signal handlers -> message queue
'-------------------------------------------------------------------------------

'Button clicked: app expects wm_lbuttondown with msg.hwnd = the button widget.
sub on_button_clicked cdecl(byval w as GtkWidget ptr, byval user as gpointer)
    msgq_push(cast(any ptr, w), WM_LBUTTONDOWN, 0, 0)
end sub

'Menu item activated: app expects wm_command with msg.wparam = item id,
'and msg.hwnd = the window the menu belongs to.
sub on_menuitem_activate cdecl(byval w as GtkWidget ptr, byval user as gpointer)
    dim as long id     = cint(cast(integer, g_object_get_data(G_OBJECT(w), "az_id")))
    dim as any ptr own = g_object_get_data(G_OBJECT(w), "az_owner")
    msgq_push(own, WM_COMMAND, id, 0)
end sub

'Window close request. We do NOT destroy: the app polls window_event_close()
'and decides. Returning TRUE suppresses GTK's default destroy.
function on_window_delete cdecl(byval w as GtkWidget ptr, _
                               byval ev as GdkEvent ptr, _
                               byval user as gpointer) as gboolean
    dim as integer i = winreg_find(cast(any ptr, w))
    if i >= 0 then winreg(i).close_flag = 1
    msgq_push(cast(any ptr, w), WM_CLOSE, 0, 0)
    return TRUE
end function

'Key release on text views / entries: app implements Ctrl+A select-all itself.
function on_key_release cdecl(byval w as GtkWidget ptr, _
                             byval ev as GdkEventKey ptr, _
                             byval user as gpointer) as gboolean
    dim as long vk = 0
    select case ev->keyval
        case GDK_KEY_a, GDK_KEY_A : vk = VK_A
        case else                 : vk = ev->keyval
    end select
    msgq_push(cast(any ptr, w), WM_KEYUP, vk, 0)
    return FALSE
end function

'Track Ctrl state so the app's getkeystate(vk_control) works.
dim shared as long g_ctrl_down = 0

function on_key_press_ctrl cdecl(byval w as GtkWidget ptr, _
                                byval ev as GdkEventKey ptr, _
                                byval user as gpointer) as gboolean
    if ev->keyval = GDK_KEY_Control_L orelse ev->keyval = GDK_KEY_Control_R then
        g_ctrl_down = 1
    end if
    return FALSE
end function

function on_key_release_ctrl cdecl(byval w as GtkWidget ptr, _
                                  byval ev as GdkEventKey ptr, _
                                  byval user as gpointer) as gboolean
    if ev->keyval = GDK_KEY_Control_L orelse ev->keyval = GDK_KEY_Control_R then
        g_ctrl_down = 0
    end if
    return FALSE
end function

'Mouse button press on a list box etc.
function on_button_press cdecl(byval w as GtkWidget ptr, _
                              byval ev as GdkEventButton ptr, _
                              byval user as gpointer) as gboolean
    if ev->button = 1 then
        msgq_push(cast(any ptr, w), WM_LBUTTONDOWN, 0, 0)
    elseif ev->button = 3 then
        msgq_push(cast(any ptr, w), WM_RBUTTONDOWN, 0, 0)
    end if
    return FALSE
end function

'-------------------------------------------------------------------------------
' Initialisation
'-------------------------------------------------------------------------------
dim shared as long gtk_ready = 0

sub gtkbe_init()
    if gtk_ready then return
    dim as long argc = 0
    dim as zstring ptr ptr argv = NULL
    gtk_init(@argc, @argv)
    msgq_init()
    gtk_ready = 1
end sub

'Pump GTK without blocking, then report whether we have a message.
'Mirrors getmessage() semantics closely enough for the app's loop.
function gtkbe_getmessage(byref m as MSG_TYPE) as long
    'Drain pending GTK events so handlers can enqueue.
    dim as integer guard = 0
    while gtk_events_pending() <> 0 andalso guard < 256
        gtk_main_iteration_do(FALSE)
        guard += 1
    wend
    return msgq_pop(m)
end function

#endif
