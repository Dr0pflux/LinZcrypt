'gtk_widgets.bi - widget primitives for the AZdecrypt GTK backend

#ifdef __fb_linux__

'Helpers

'Resolve the GtkFixed container for a window handle the app passes as parent.
function gtkbe_fixed_of(byval parent as any ptr) as GtkWidget ptr
    dim as integer i = winreg_find(parent)
    if i >= 0 then return winreg(i).fixed
    return NULL
end function

'Place a widget at absolute coords inside a parent window.
sub gtkbe_place(byval parent as any ptr, byval child as GtkWidget ptr, _
                byval x as long, byval y as long, byval w as long, byval h as long)
    dim as GtkWidget ptr fx = gtkbe_fixed_of(parent)
    if fx = NULL orelse child = NULL then return
    gtk_widget_set_size_request(child, w, h)
    gtk_fixed_put(GTK_FIXED(fx), child, x, y)
    gtk_widget_show(child)
end sub

'Wrap a widget in a scrolled window and place that instead. Returns the inner
function gtkbe_place_scrolled(byval parent as any ptr, byval child as GtkWidget ptr, _
                              byval x as long, byval y as long, _
                              byval w as long, byval h as long) as GtkWidget ptr
    dim as GtkWidget ptr fx = gtkbe_fixed_of(parent)
    if fx = NULL orelse child = NULL then return child

    dim as GtkWidget ptr sc = gtk_scrolled_window_new(NULL, NULL)
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(sc), _
                                   GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC)
    gtk_container_add(GTK_CONTAINER(sc), child)
    gtk_widget_set_size_request(sc, w, h)
    gtk_fixed_put(GTK_FIXED(fx), sc, x, y)
    gtk_widget_show_all(sc)

    'Remember the scroller so later resizes can find it.
    g_object_set_data(G_OBJECT(child), "az_scroller", cast(gpointer, sc))
    return child
end function

'Windows

function gtkbe_window_new(byval x as long, byval y as long, _
                          byval w as long, byval h as long, _
                          byref title as string) as any ptr
    gtkbe_init()
    if winreg_n >= MAXWIN then return NULL

    dim as GtkWidget ptr win = gtk_window_new(GTK_WINDOW_TOPLEVEL)
    gtk_window_set_title(GTK_WINDOW(win), title)
    gtk_window_set_default_size(GTK_WINDOW(win), w, h)
    gtk_window_set_resizable(GTK_WINDOW(win), TRUE)
    if x >= 0 andalso y >= 0 then gtk_window_move(GTK_WINDOW(win), x, y)

    dim as GtkWidget ptr vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0)
    gtk_container_add(GTK_CONTAINER(win), vbox)

    dim as GtkWidget ptr fx = gtk_fixed_new()
    'The app lays out controls at absolute coordinates within these dimensions.
    'Request exactly that size so the window fits its content: no dead margin on
    'the right, and the window manager has a sane minimum to work from.
    gtk_widget_set_size_request(fx, w, h)
    gtk_box_pack_start(GTK_BOX(vbox), fx, TRUE, TRUE, 0)

    dim as GtkAccelGroup ptr ag = gtk_accel_group_new()
    gtk_window_add_accel_group(GTK_WINDOW(win), ag)

    dim as integer i = winreg_n
    winreg(i).win        = win
    winreg(i).fixed      = fx
    winreg(i).vbox       = vbox
    winreg(i).menubar    = NULL
    winreg(i).accel      = ag
    winreg(i).close_flag = 0
    winreg(i).in_use     = 1
    winreg_n += 1

    g_signal_connect(G_OBJECT(win), "delete-event", _
                     G_CALLBACK(@on_window_delete), NULL)
    g_signal_connect(G_OBJECT(win), "key-press-event", _
                     G_CALLBACK(@on_key_press_ctrl), NULL)
    g_signal_connect(G_OBJECT(win), "key-release-event", _
                     G_CALLBACK(@on_key_release_ctrl), NULL)

    gtk_widget_show_all(win)
    return cast(any ptr, win)
end function

sub gtkbe_window_destroy(byval hw as any ptr)
    dim as integer i = winreg_find(hw)
    if i >= 0 then
        winreg(i).in_use = 0
        gtk_widget_destroy(winreg(i).win)
        winreg(i).win = NULL
    end if
end sub

'Hide rather than destroy - the app reopens sub-windows repeatedly.
sub gtkbe_window_hide(byval hw as any ptr)
    dim as integer i = winreg_find(hw)
    if i >= 0 then
        gtk_widget_hide(winreg(i).win)
        winreg(i).close_flag = 0
    end if
end sub

'Consume-and-clear: matches window_event_close() semantics (edge-triggered).
function gtkbe_window_closed(byval hw as any ptr) as long
    dim as integer i = winreg_find(hw)
    if i < 0 then return 0
    if winreg(i).close_flag then
        winreg(i).close_flag = 0
        return 1
    end if
    return 0
end function

sub gtkbe_window_getposition(byval hw as any ptr, _
                             byref xl as long, byref yt as long, _
                             byref xr as long, byref yb as long)
    xl = 0 : yt = 0 : xr = 0 : yb = 0
    dim as integer i = winreg_find(hw)
    if i < 0 then return
    dim as gint px, py, pw, ph
    gtk_window_get_position(GTK_WINDOW(winreg(i).win), @px, @py)
    gtk_window_get_size(GTK_WINDOW(winreg(i).win), @pw, @ph)
    xl = px : yt = py : xr = px + pw : yb = py + ph
end sub

sub gtkbe_setwindowtext(byval hw as any ptr, byref t as string)
    dim as integer i = winreg_find(hw)
    if i >= 0 then
        gtk_window_set_title(GTK_WINDOW(winreg(i).win), t)
    else
        'Not a window - treat as a label-ish widget.
        if hw then gtk_label_set_text(GTK_LABEL(cast(GtkWidget ptr, hw)), t)
    end if
end sub

sub gtkbe_setfocus(byval hw as any ptr)
    if hw then gtk_widget_grab_focus(cast(GtkWidget ptr, hw))
end sub

'Buttons / checkboxes / radio buttons

function gtkbe_button_new(byval x as long, byval y as long, _
                          byval w as long, byval h as long, _
                          byref label as string, byval parent as any ptr) as any ptr
    dim as GtkWidget ptr b = gtk_button_new_with_label(label)
    g_signal_connect(G_OBJECT(b), "clicked", G_CALLBACK(@on_button_clicked), NULL)
    gtkbe_place(parent, b, x, y, w, h)
    return cast(any ptr, b)
end function

function gtkbe_checkbox_new(byval x as long, byval y as long, _
                            byval w as long, byval h as long, _
                            byref label as string, byval parent as any ptr) as any ptr
    dim as GtkWidget ptr c = gtk_check_button_new_with_label(label)
    g_signal_connect(G_OBJECT(c), "clicked", G_CALLBACK(@on_button_clicked), NULL)
    gtkbe_place(parent, c, x, y, w, h)
    return cast(any ptr, c)
end function

sub gtkbe_checkbox_setcheck(byval hw as any ptr, byval state as long)
    if hw = NULL then return
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cast(GtkWidget ptr, hw)), _
                                 iif(state <> 0, TRUE, FALSE))
end sub

function gtkbe_checkbox_getcheck(byval hw as any ptr) as long
    if hw = NULL then return 0
    if gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(cast(GtkWidget ptr, hw))) then return 1
    return 0
end function

function gtkbe_radiobutton_new(byval x as long, byval y as long, _
                               byval w as long, byval h as long, _
                               byref label as string, byval style as long, _
                               byval parent as any ptr) as any ptr
    dim as GtkWidget ptr fx = gtkbe_fixed_of(parent)

    'WS_GROUP (nonzero style) starts a new radio group.
    if style <> 0 then rgrp_break(fx)

    dim as GtkWidget ptr prev = rgrp_last_for(fx)
    dim as GtkWidget ptr r
    if prev = NULL then
        r = gtk_radio_button_new_with_label(NULL, label)
    else
        r = gtk_radio_button_new_with_label_from_widget(GTK_RADIO_BUTTON(prev), label)
    end if
    rgrp_set_last(fx, r)

    g_signal_connect(G_OBJECT(r), "clicked", G_CALLBACK(@on_button_clicked), NULL)
    gtkbe_place(parent, r, x, y, w, h)
    return cast(any ptr, r)
end function

sub gtkbe_radiobutton_setcheck(byval hw as any ptr, byval state as long)
    if hw = NULL then return
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cast(GtkWidget ptr, hw)), _
                                 iif(state <> 0, TRUE, FALSE))
end sub

function gtkbe_radiobutton_getcheck(byval hw as any ptr) as long
    if hw = NULL then return 0
    if gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(cast(GtkWidget ptr, hw))) then return 1
    return 0
end function

'Labels

function gtkbe_label_new(byval x as long, byval y as long, _
                         byval w as long, byval h as long, _
                         byref text as string, byval parent as any ptr) as any ptr
    dim as GtkWidget ptr l = gtk_label_new(text)
    gtk_label_set_xalign(GTK_LABEL(l), 0.0)
    gtk_label_set_yalign(GTK_LABEL(l), 0.5)
    gtkbe_place(parent, l, x, y, w, h)
    return cast(any ptr, l)
end function

sub gtkbe_label_settext(byval hw as any ptr, byref text as string)
    if hw then gtk_label_set_text(GTK_LABEL(cast(GtkWidget ptr, hw)), text)
end sub

'Edit boxes / multiline editors

function gtkbe_editbox_new(byval x as long, byval y as long, _
                           byval w as long, byval h as long, _
                           byref text as string, byval readonly_ as long, _
                           byval parent as any ptr) as any ptr
    dim as GtkWidget ptr e = gtk_entry_new()
    gtk_entry_set_text(GTK_ENTRY(e), text)
    if readonly_ then gtk_editable_set_editable(GTK_EDITABLE(e), FALSE)
    g_object_set_data(G_OBJECT(e), "az_multiline", cast(gpointer, 0))
    g_signal_connect(G_OBJECT(e), "key-release-event", _
                     G_CALLBACK(@on_key_release), NULL)
    gtkbe_place(parent, e, x, y, w, h)
    return cast(any ptr, e)
end function

function gtkbe_editor_new(byval x as long, byval y as long, _
                          byval w as long, byval h as long, _
                          byref text as string, byval readonly_ as long, _
                          byval parent as any ptr) as any ptr
    dim as GtkWidget ptr tv = gtk_text_view_new()
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(tv), GTK_WRAP_NONE)
    if readonly_ then gtk_text_view_set_editable(GTK_TEXT_VIEW(tv), FALSE)

    dim as GtkTextBuffer ptr buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(tv))
    gtk_text_buffer_set_text(buf, text, -1)

    g_object_set_data(G_OBJECT(tv), "az_multiline", cast(gpointer, 1))
    g_signal_connect(G_OBJECT(tv), "key-release-event", _
                     G_CALLBACK(@on_key_release), NULL)

    gtkbe_place_scrolled(parent, tv, x, y, w, h)
    return cast(any ptr, tv)
end function

function gtkbe_is_multiline(byval hw as any ptr) as long
    if hw = NULL then return 0
    return cint(cast(integer, g_object_get_data(G_OBJECT(cast(GtkWidget ptr, hw)), "az_multiline")))
end function

sub gtkbe_editbox_settext(byval hw as any ptr, byref text as string)
    if hw = NULL then return
    if gtkbe_is_multiline(hw) then
        dim as GtkTextBuffer ptr buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(cast(GtkWidget ptr, hw)))
        gtk_text_buffer_set_text(buf, text, -1)
    else
        gtk_entry_set_text(GTK_ENTRY(cast(GtkWidget ptr, hw)), text)
    end if
end sub

function gtkbe_editbox_gettext(byval hw as any ptr) as string
    if hw = NULL then return ""
    if gtkbe_is_multiline(hw) then
        dim as GtkTextBuffer ptr buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(cast(GtkWidget ptr, hw)))
        dim as GtkTextIter s, e
        gtk_text_buffer_get_start_iter(buf, @s)
        gtk_text_buffer_get_end_iter(buf, @e)
        dim as gchar ptr p = gtk_text_buffer_get_text(buf, @s, @e, FALSE)
        dim as string r = ""
        if p then
            r = *cast(zstring ptr, p)
            g_free(p)
        end if
        return r
    else
        dim as const gchar ptr p = gtk_entry_get_text(GTK_ENTRY(cast(GtkWidget ptr, hw)))
        if p then return *cast(zstring ptr, p)
        return ""
    end if
end function

'Select-all, used by the app's Ctrl+A hack via EM_SETSEL.
sub gtkbe_editbox_selectall(byval hw as any ptr)
    if hw = NULL then return
    if gtkbe_is_multiline(hw) then
        dim as GtkTextBuffer ptr buf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(cast(GtkWidget ptr, hw)))
        dim as GtkTextIter s, e
        gtk_text_buffer_get_start_iter(buf, @s)
        gtk_text_buffer_get_end_iter(buf, @e)
        gtk_text_buffer_select_range(buf, @s, @e)
    else
        gtk_editable_select_region(GTK_EDITABLE(cast(GtkWidget ptr, hw)), 0, -1)
    end if
end sub

'List boxes

function gtkbe_listbox_new(byval x as long, byval y as long, _
                           byval w as long, byval h as long, _
                           byval parent as any ptr) as any ptr
    dim as GtkListStore ptr store = gtk_list_store_new(1, G_TYPE_STRING)
    dim as GtkWidget ptr tv = gtk_tree_view_new_with_model(GTK_TREE_MODEL(store))
    gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(tv), FALSE)

    dim as GtkCellRenderer ptr rend = gtk_cell_renderer_text_new()
    dim as GtkTreeViewColumn ptr col = _
        gtk_tree_view_column_new_with_attributes("", rend, "text", 0, NULL)
    gtk_tree_view_append_column(GTK_TREE_VIEW(tv), col)

    g_object_set_data(G_OBJECT(tv), "az_store", cast(gpointer, store))
    g_signal_connect(G_OBJECT(tv), "button-press-event", _
                     G_CALLBACK(@on_button_press), NULL)

    gtkbe_place_scrolled(parent, tv, x, y, w, h)
    return cast(any ptr, tv)
end function

function gtkbe_store_of(byval hw as any ptr) as GtkListStore ptr
    if hw = NULL then return NULL
    return cast(GtkListStore ptr, _
                g_object_get_data(G_OBJECT(cast(GtkWidget ptr, hw)), "az_store"))
end function

sub gtkbe_listbox_addstring(byval hw as any ptr, byref text as string)
    dim as GtkListStore ptr st = gtkbe_store_of(hw)
    if st = NULL then return
    dim as GtkTreeIter it
    gtk_list_store_append(st, @it)
    gtk_list_store_set(st, @it, 0, cptr(zstring ptr, strptr(text)), -1)
end sub

sub gtkbe_listbox_deletestring(byval hw as any ptr, byval index as long)
    dim as GtkListStore ptr st = gtkbe_store_of(hw)
    if st = NULL then return
    dim as GtkTreeIter it
    if gtk_tree_model_iter_nth_child(GTK_TREE_MODEL(st), @it, NULL, index) then
        gtk_list_store_remove(st, @it)
    end if
end sub

sub gtkbe_listbox_replacestring(byval hw as any ptr, byval index as long, byref text as string)
    dim as GtkListStore ptr st = gtkbe_store_of(hw)
    if st = NULL then return
    dim as GtkTreeIter it
    if gtk_tree_model_iter_nth_child(GTK_TREE_MODEL(st), @it, NULL, index) then
        gtk_list_store_set(st, @it, 0, cptr(zstring ptr, strptr(text)), -1)
    else
        'Index past end - append instead, matching Win32 tolerance.
        gtk_list_store_append(st, @it)
        gtk_list_store_set(st, @it, 0, cptr(zstring ptr, strptr(text)), -1)
    end if
end sub

sub gtkbe_listbox_resetcontent(byval hw as any ptr)
    dim as GtkListStore ptr st = gtkbe_store_of(hw)
    if st then gtk_list_store_clear(st)
end sub

function gtkbe_listbox_getcount(byval hw as any ptr) as long
    dim as GtkListStore ptr st = gtkbe_store_of(hw)
    if st = NULL then return 0
    return gtk_tree_model_iter_n_children(GTK_TREE_MODEL(st), NULL)
end function

sub gtkbe_listbox_setcursel(byval hw as any ptr, byval index as long)
    if hw = NULL then return
    dim as GtkTreeSelection ptr sel = gtk_tree_view_get_selection(GTK_TREE_VIEW(cast(GtkWidget ptr, hw)))
    dim as GtkListStore ptr st = gtkbe_store_of(hw)
    if st = NULL orelse sel = NULL then return
    dim as GtkTreeIter it
    if gtk_tree_model_iter_nth_child(GTK_TREE_MODEL(st), @it, NULL, index) then
        gtk_tree_selection_select_iter(sel, @it)
    end if
end sub

function gtkbe_listbox_getcursel(byval hw as any ptr) as long
    if hw = NULL then return -1
    dim as GtkTreeSelection ptr sel = gtk_tree_view_get_selection(GTK_TREE_VIEW(cast(GtkWidget ptr, hw)))
    if sel = NULL then return -1
    dim as GtkTreeModel ptr mdl
    dim as GtkTreeIter it
    if gtk_tree_selection_get_selected(sel, @mdl, @it) = 0 then return -1
    dim as GtkTreePath ptr path = gtk_tree_model_get_path(mdl, @it)
    if path = NULL then return -1
    dim as gint ptr idx = gtk_tree_path_get_indices(path)
    dim as long r = -1
    if idx then r = idx[0]
    gtk_tree_path_free(path)
    return r
end function

function gtkbe_listbox_gettext(byval hw as any ptr, byval index as long) as string
    dim as GtkListStore ptr st = gtkbe_store_of(hw)
    if st = NULL then return ""
    dim as GtkTreeIter it
    if gtk_tree_model_iter_nth_child(GTK_TREE_MODEL(st), @it, NULL, index) = 0 then return ""
    dim as gchar ptr p = NULL
    gtk_tree_model_get(GTK_TREE_MODEL(st), @it, 0, @p, -1)
    dim as string r = ""
    if p then
        r = *cast(zstring ptr, p)
        g_free(p)
    end if
    return r
end function

'Menus

function gtkbe_createmenu() as any ptr
    dim as GtkWidget ptr m = gtk_menu_new()
    return cast(any ptr, m)
end function

'Attach a submenu to a window's menu bar under a title.
sub gtkbe_menutitle(byval hwin as any ptr, byval hmenu as any ptr, byref title as string)
    dim as integer i = winreg_find(hwin)
    if i < 0 orelse hmenu = NULL then return

    if winreg(i).menubar = NULL then
        winreg(i).menubar = gtk_menu_bar_new()
        gtk_box_pack_start(GTK_BOX(winreg(i).vbox), winreg(i).menubar, FALSE, FALSE, 0)
        'Force the menu bar to the very top, above the fixed content area.
        gtk_box_reorder_child(GTK_BOX(winreg(i).vbox), winreg(i).menubar, 0)
        gtk_widget_show(winreg(i).menubar)
    end if

    dim as GtkWidget ptr root = gtk_menu_item_new_with_label(title)
    gtk_menu_item_set_submenu(GTK_MENU_ITEM(root), cast(GtkWidget ptr, hmenu))
    gtk_menu_shell_append(GTK_MENU_SHELL(winreg(i).menubar), root)
    gtk_widget_show_all(winreg(i).menubar)
end sub

'Add an item with an integer command id to a submenu.
sub gtkbe_menuitem(byval hmenu as any ptr, byval id as long, byref itemname as string, _
                   byval owner as any ptr)
    if hmenu = NULL then return
    dim as GtkWidget ptr it
    if itemname = "-" orelse itemname = "" then
        it = gtk_separator_menu_item_new()
    else
        it = gtk_menu_item_new_with_label(itemname)
        g_object_set_data(G_OBJECT(it), "az_id", cast(gpointer, cast(integer, id)))
        g_object_set_data(G_OBJECT(it), "az_owner", owner)
        g_signal_connect(G_OBJECT(it), "activate", _
                         G_CALLBACK(@on_menuitem_activate), NULL)
    end if
    gtk_menu_shell_append(GTK_MENU_SHELL(cast(GtkWidget ptr, hmenu)), it)
    gtk_widget_show(it)
end sub

'Find a menu item by id within a submenu (for check/uncheck and rename).
function gtkbe_menu_find(byval hmenu as any ptr, byval id as long) as GtkWidget ptr
    if hmenu = NULL then return NULL
    dim as GList ptr kids = gtk_container_get_children(GTK_CONTAINER(cast(GtkWidget ptr, hmenu)))
    dim as GList ptr p = kids
    dim as GtkWidget ptr found = NULL
    while p
        dim as GtkWidget ptr w = cast(GtkWidget ptr, p->data)
        dim as long wid = cint(cast(integer, g_object_get_data(G_OBJECT(w), "az_id")))
        if wid = id then
            found = w
            exit while
        end if
        p = p->next
    wend
    if kids then g_list_free(kids)
    return found
end function

sub gtkbe_menu_settext(byval hmenu as any ptr, byval id as long, byref text as string)
    dim as GtkWidget ptr it = gtkbe_menu_find(hmenu, id)
    if it then gtk_menu_item_set_label(GTK_MENU_ITEM(it), text)
end sub

sub gtkbe_setmenu(byval hwin as any ptr, byval hmenu as any ptr)
    'Menu bar is attached incrementally by gtkbe_menutitle; nothing to do.
end sub

sub gtkbe_drawmenubar(byval hwin as any ptr)
    dim as integer i = winreg_find(hwin)
    if i >= 0 andalso winreg(i).menubar then gtk_widget_show_all(winreg(i).menubar)
end sub

'File dialogs

function gtkbe_loadsavedialog(byval dosave as long, byref title as string, _
                              byref initdir as string) as string
    gtkbe_init()

    dim as GtkWidget ptr parent = NULL
    if winreg_n > 0 andalso winreg(0).in_use then parent = winreg(0).win

    dim as GtkWidget ptr dlg
    if dosave then
        dlg = gtk_file_chooser_dialog_new(iif(len(title), title, "Save file"), _
                GTK_WINDOW(parent), GTK_FILE_CHOOSER_ACTION_SAVE, _
                "_Cancel", GTK_RESPONSE_CANCEL, "_Save", GTK_RESPONSE_ACCEPT, NULL)
        gtk_file_chooser_set_do_overwrite_confirmation(GTK_FILE_CHOOSER(dlg), TRUE)
    else
        dlg = gtk_file_chooser_dialog_new(iif(len(title), title, "Open file"), _
                GTK_WINDOW(parent), GTK_FILE_CHOOSER_ACTION_OPEN, _
                "_Cancel", GTK_RESPONSE_CANCEL, "_Open", GTK_RESPONSE_ACCEPT, NULL)
    end if

    if len(initdir) then
        gtk_file_chooser_set_current_folder(GTK_FILE_CHOOSER(dlg), initdir)
    end if

    dim as string result = ""
    if gtk_dialog_run(GTK_DIALOG(dlg)) = GTK_RESPONSE_ACCEPT then
        dim as gchar ptr fn = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dlg))
        if fn then
            result = *cast(zstring ptr, fn)
            g_free(fn)
        end if
    end if
    gtk_widget_destroy(dlg)

    'Flush the dialog teardown so it does not linger.
    while gtk_events_pending() <> 0
        gtk_main_iteration_do(FALSE)
    wend

    return result
end function

'Fonts

sub gtkbe_control_setfont(byval hw as any ptr, byref fontname as string, byval h as long)
    if hw = NULL then return
    dim as string css = "* { font-family: """ & fontname & """; font-size: " & h & "px; }"
    dim as GtkCssProvider ptr prov = gtk_css_provider_new()
    gtk_css_provider_load_from_data(prov, css, -1, NULL)
    dim as GtkStyleContext ptr ctx = gtk_widget_get_style_context(cast(GtkWidget ptr, hw))
    gtk_style_context_add_provider(ctx, GTK_STYLE_PROVIDER(prov), _
                                   GTK_STYLE_PROVIDER_PRIORITY_APPLICATION)
    g_object_unref(prov)
end sub

#endif
