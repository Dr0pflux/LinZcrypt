#!/usr/bin/env python3
"""Populate Ciphers/ with the Liber Primus, one file per page.

Downloads the rtkd/iddqd master transcription and writes, per page:
    LP_page_NN.txt     rune indices 1..29, 0 = word break (AZdecrypt numeric input)
    LP_page_NN.runes   the original runes, for reference

    python3 make_lp_ciphers.py [--out DIR] [--source FILE]
"""

import argparse
import os
import re
import sys
import urllib.request

SOURCE_URL = (
    "https://raw.githubusercontent.com/rtkd/iddqd/master/"
    "liber-primus__transcription--master/"
    "liber-primus__transcription--master.txt"
)

# Gematria Primus. Index i -> cipher symbol i+1.
GP = [
    ("\u16A0", "F"),   ("\u16A2", "U"),   ("\u16A6", "TH"),  ("\u16A9", "O"),
    ("\u16B1", "R"),   ("\u16B3", "C"),   ("\u16B7", "G"),   ("\u16B9", "W"),
    ("\u16BB", "H"),   ("\u16BE", "N"),   ("\u16C1", "I"),   ("\u16C4", "J"),
    ("\u16C7", "EO"),  ("\u16C8", "P"),   ("\u16C9", "X"),   ("\u16CA", "S"),
    ("\u16CF", "T"),   ("\u16D2", "B"),   ("\u16D6", "E"),   ("\u16D7", "M"),
    ("\u16DA", "L"),   ("\u16DD", "NG"),  ("\u16DF", "OE"),  ("\u16DE", "D"),
    ("\u16AA", "A"),   ("\u16AB", "AE"),  ("\u16A3", "Y"),   ("\u16E1", "IA"),
    ("\u16E0", "EA"),
]
RUNE_TO_IDX = {r: i for i, (r, _) in enumerate(GP)}

WORD_SEPARATORS = "-."
STRUCTURAL = "&$\u00a7/"
PAGE_DELIM = "%"


def fetch(url):
    with urllib.request.urlopen(url, timeout=60) as r:
        return r.read().decode("utf-8")


def strip_header(text):
    """Drop the delimiter legend at the top of the transcription."""
    idx = text.find(PAGE_DELIM)
    first_rune = min(
        (text.find(r) for r, _ in GP if text.find(r) >= 0),
        default=-1,
    )
    if first_rune < 0:
        return text
    # Whichever comes first, so page 0 is not lost.
    start = first_rune if idx < 0 else min(idx, first_rune)
    return text[start:]


def split_pages(text):
    pages = text.split(PAGE_DELIM)
    return [p for p in pages if any(ch in RUNE_TO_IDX for ch in p)]


def page_to_numbers(page):
    """Convert one page to symbol numbers. 0 marks a word break."""
    out = []
    prev_was_sep = True
    for ch in page:
        if ch in RUNE_TO_IDX:
            out.append(RUNE_TO_IDX[ch] + 1)
            prev_was_sep = False
        elif ch in WORD_SEPARATORS:
            if not prev_was_sep and out:
                out.append(0)
                prev_was_sep = True
        elif ch in STRUCTURAL or ch.isspace():
            continue
        # digits and latin (page numbers, hashes) are skipped
    while out and out[-1] == 0:
        out.pop()
    return out


def page_runes(page):
    return "".join(ch for ch in page if ch in RUNE_TO_IDX or ch in WORD_SEPARATORS)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="Ciphers", help="output directory")
    ap.add_argument("--source", help="local transcription file instead of downloading")
    args = ap.parse_args()

    if args.source:
        with open(args.source, encoding="utf-8") as f:
            text = f.read()
        print(f"Using local transcription: {args.source}")
    else:
        print("Downloading transcription from rtkd/iddqd ...")
        try:
            text = fetch(SOURCE_URL)
        except Exception as e:
            print(f"Download failed: {e}", file=sys.stderr)
            print("Download the file manually and pass it with --source.", file=sys.stderr)
            return 1

    text = strip_header(text)
    pages = split_pages(text)
    if not pages:
        print("No runic pages found in the transcription.", file=sys.stderr)
        return 1

    os.makedirs(args.out, exist_ok=True)

    total_runes = 0
    written = 0
    for n, page in enumerate(pages):
        nums = page_to_numbers(page)
        if not nums:
            continue
        runes = len([x for x in nums if x != 0])
        total_runes += runes

        base = os.path.join(args.out, f"LP_page_{n:02d}")
        with open(base + ".txt", "w", encoding="utf-8") as f:
            f.write(" ".join(str(x) for x in nums) + "\n")
        with open(base + ".runes", "w", encoding="utf-8") as f:
            f.write(page_runes(page) + "\n")
        written += 1
        print(f"  LP_page_{n:02d}: {runes} runes")

    print()
    print(f"Wrote {written} pages ({total_runes} runes total) to {args.out}/")
    print()
    print("To use: File > Open, pick a LP_page_NN.txt, then load a runeglish")
    print("n-gram set and run the Substitution solver.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
