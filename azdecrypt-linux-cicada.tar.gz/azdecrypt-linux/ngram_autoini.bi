'Generate a missing n-gram .ini by scanning the n-gram file.

#ifndef NGRAM_AUTOINI_BI
#define NGRAM_AUTOINI_BI

'Report token length and character set. Plain text only; gzip ships with .ini.
function ngram_autoini_scan(byref path_ as string, byref outlen as integer, _
                            byref outalpha as string) as integer

    dim as integer fh = freefile
    if open(path_ for input as #fh) <> 0 then return 0

    dim as integer seen(0 to 255)
    dim as integer nlines = 0, toklen = 0, consistent = 1
    dim as string ln, tok

    'Whole file: rare letters appear far down, and a short alphabet breaks scoring.
    while not eof(fh)
        line input #fh, ln
        ln = trim(ln)

        if len(ln) > 0 then
            'Entry is "<ngram> <count>"; take the part before the first space/tab.
            dim as integer sp = instr(ln, " ")
            dim as integer tb = instr(ln, chr(9))
            if tb > 0 andalso (sp = 0 orelse tb < sp) then sp = tb
            if sp > 0 then tok = left(ln, sp - 1) else tok = ln

            if len(tok) > 0 then
                if toklen = 0 then
                    toklen = len(tok)
                elseif nlines < 5000 andalso len(tok) <> toklen then
                    consistent = 0
                end if

                for i as integer = 1 to len(tok)
                    seen(asc(tok, i)) = 1
                next

                nlines += 1
            end if
        end if
    wend

    close #fh

    if nlines = 0 orelse toklen = 0 orelse consistent = 0 then return 0

    'Build the alphabet in a stable order: A-Z, a-z, 0-9, then anything else.
    dim as string al = ""
    for c as integer = asc("A") to asc("Z")
        if seen(c) then al += chr(c)
    next
    for c as integer = asc("a") to asc("z")
        if seen(c) then al += chr(c)
    next
    for c as integer = asc("0") to asc("9")
        if seen(c) then al += chr(c)
    next
    for c as integer = 33 to 255
        if seen(c) then
            if (c < asc("0") orelse c > asc("9")) andalso _
               (c < asc("A") orelse c > asc("Z")) andalso _
               (c < asc("a") orelse c > asc("z")) then al += chr(c)
        end if
    next

    if len(al) = 0 then return 0

    outlen   = toklen
    outalpha = al
    return 1

end function

'Write an .ini for `ngrampath` at `inipath`. Returns 1 on success.
function ngram_autoini_write(byref ngrampath as string, byref inipath as string) as integer

    dim as integer nsize = 0
    dim as string alpha = ""

    if ngram_autoini_scan(ngrampath, nsize, alpha) = 0 then return 0
    if nsize < 2 orelse nsize > 7 then return 0   'loader only accepts 2..7

    'Defaults matching AZdecrypt's usual letter n-gram settings.
    dim as double factor = 1.0
    dim as double entw   = 1.0

    dim as integer fh = freefile
    if open(inipath for output as #fh) <> 0 then return 0
    print #fh, "ngram_size=" & nsize
    print #fh, "ngram_factor=" & factor
    print #fh, "entropy_weight=" & entw
    print #fh, "alphabet=" & alpha
    print #fh, "temperature=800"
    print #fh, "items=0"
    close #fh

    return 1

end function

#endif
