'thread_cicada_solve.bi - background worker for the Cicada solvers

sub cicada_solve_thread(byval none as any ptr)

    cicsolve_running = 1
    cicsolve_stop = 0

    dim as string msgs = cic_build_map()
    if msgs <> "Ok" then
        ui_editbox_settext(output_text, msgs)
        task_active = "none"
        cicsolve_running = 0
        return
    end if

    msgs = cic_prepare()
    if msgs <> "Ok" then
        ui_editbox_settext(output_text, msgs)
        task_active = "none"
        cicsolve_running = 0
        return
    end if

    dim as double t0 = timer
    dim as string o = ""
    dim as integer bestkey(0 to 65535)

    select case cicsolve_mode

        case CICSOLVE_VIGENERE, CICSOLVE_AUTOKEY

            dim as integer isauto = iif(cicsolve_mode = CICSOLVE_AUTOKEY, 1, 0)
            dim as string what = iif(isauto, "autokey primer", "Vigenere key")

            o = "Solving for a " + what + lb
            o += "Runes: " + str(cic_rn) + "   lengths " + str(cicsolve_minlen) + _
                 " to " + str(cicsolve_maxlen) + "   restarts " + str(cicsolve_restarts) + lb
            o += "Scoring with the loaded " + str(ngram_size) + "-gram set." + lb
            o += "Alphabet: " + cic_map_desc + lb + lb
            o += "  len        score   key" + lb

            dim as longint overall = -1
            dim as integer overall_len = 0
            dim as string overall_key = ""

            for klen as integer = cicsolve_minlen to cicsolve_maxlen

                if cicsolve_stop then exit for

                dim as integer iters = 4000 + klen * 3000

                dim as integer k(0 to 1023)
                dim as longint sc = cic_anneal(klen, iters, cicsolve_restarts, k(), isauto)

                dim as double norm = sc / (1.0 + klen * 0.5)

                dim as string kl = cic_key_to_latin(k(), klen)
                o += "  " + str(klen) + string(iif(klen < 10, 4, 3), " ") + _
                     str(sc) + "   " + kl + lb

                ui_editbox_settext(solver_text, "Cicada solver: length " + str(klen) + _
                                   " of " + str(cicsolve_maxlen) + lb + _
                                   "Best so far: " + overall_key)

                if norm > overall then
                    overall = norm
                    overall_len = klen
                    overall_key = kl
                    for i as integer = 0 to klen-1
                        bestkey(i) = k(i)
                    next
                end if

            next

            if overall_len > 0 then
                if isauto then
                    cic_score_autokey(bestkey(), overall_len)
                else
                    cic_score_key(bestkey(), overall_len)
                end if
                o += lb + "Best: length " + str(overall_len) + ", key " + overall_key + lb + lb
                o += "Plaintext:" + lb + cic_plain_preview(1200) + lb + lb
                o += "Judge this by whether the KEY reads as a word and the plaintext" + lb
                o += "reads as language. A hill-climber returns its best candidate" + lb
                o += "whether or not one exists, so a top score on its own means" + lb
                o += "nothing - compare it against the scores of the other lengths." + lb
            end if

        case CICSOLVE_RUNNINGKEY

            dim as integer iters = cic_rn * 260
            if iters > 8000000 then iters = 8000000

            ui_editbox_settext(solver_text, "Cicada solver: running key, " + _
                               str(cic_rn) + " positions")

            dim as longint sc = cic_anneal_stream(iters, bestkey())

            dim as string keylat = ""
            gp_init()
            for i as integer = 1 to cic_rn
                if i > 1200 then exit for
                keylat += lcase(gp_lat(bestkey(i)))
            next

            o = "Running key solve (free key stream)" + lb
            o += "Runes: " + str(cic_rn) + "   score " + str(sc) + lb + lb
            o += "Plaintext:" + lb + cic_plain_preview(1200) + lb + lb
            o += "Derived key stream:" + lb + keylat + lb + lb
            o += "READ THIS BEFORE BELIEVING IT." + lb
            o += "A free key stream has one unknown per rune, so ANY plaintext is" + lb
            o += "reachable and the search will always return fluent-looking text." + lb
            o += "The n-gram score cannot tell a real decryption from a fitted one." + lb
            o += "The evidence is the key: a genuine running key is itself a passage" + lb
            o += "of text. If the key above is gibberish, this is a fit, not a solve." + lb

        case CICSOLVE_SCAN

            o = "Transform scan" + lb
            o += "Runes: " + str(cic_rn) + "   scoring with the loaded " + _
                 str(ngram_size) + "-gram set." + lb
            o += "Alphabet: " + cic_map_desc + lb + lb
            o += "Enumerates closed-form transforms rather than searching a key," + lb
            o += "so every score here is exact, not a hill-climber's best effort." + lb + lb

            dim as integer k(0 to 65535)
            dim as longint bsc = -1
            dim as string bname = ""
            dim as string rows = ""

            for atb as integer = 0 to 1
                for fam as integer = 0 to 4

                    if cicsolve_stop then exit for

                    dim as integer kn = cic_rn
                    select case fam
                        case 0 : for i as integer = 0 to kn-1 : k(i) = 0 : next
                        case 1 : cic_key_primes(k(), kn)
                        case 2 : cic_key_totient(k(), kn)
                        case 3 : cic_key_totient_primes(k(), kn)
                        case 4 : cic_key_fibonacci(k(), kn)
                    end select

                    dim as string famname
                    select case fam
                        case 0 : famname = "none"
                        case 1 : famname = "primes"
                        case 2 : famname = "totients"
                        case 3 : famname = "totient primes"
                        case 4 : famname = "fibonacci"
                    end select

                    for sh as integer = 0 to GP_COUNT-1
                      for ordr as integer = 0 to 1

                        if atb = 0 andalso ordr = 1 then exit for

                        for i as integer = 1 to cic_rn
                            dim as integer v = cic_r(i)
                            if atb andalso ordr = 0 then v = GP_COUNT - 1 - v
                            v = v - k(i-1) - sh
                            v = ((v mod GP_COUNT) + GP_COUNT) mod GP_COUNT
                            if atb andalso ordr = 1 then v = GP_COUNT - 1 - v
                            cic_pl(i) = v
                        next

                        dim as longint sc = cic_score_runes(cic_pl(), cic_rn)
                        dim as string abn = ""
                        if atb then
                            if ordr = 0 then abn = "atbash then key + " else abn = "key then atbash + "
                        end if
                        dim as string nm = abn + "shift " + str(sh) + " + " + famname

                        if sc > bsc then
                            bsc = sc
                            bname = nm
                        end if
                        if sc > 0 then
                            rows += "  " + str(sc) + "   " + nm + lb
                        end if

                      next
                    next
                next
            next

            o += "Best: " + bname + "   score " + str(bsc) + lb + lb
            o += "All non-zero results:" + lb + rows + lb
            o += "A transform is worth pursuing only if it clears the rest by a" + lb
            o += "wide margin. Scores bunched together mean none of them fits." + lb

    end select

    if cicsolve_stop then
        o += lb + "(stopped early by request - results above are partial)" + lb
    end if

    o += lb + "Elapsed: " + left(str(timer - t0) + "000", 5) + " s" + lb

    ui_editbox_settext(output_text, o)
    ui_editbox_settext(solver_text, "")
    task_active = "none"
    cicsolve_running = 0

end sub
