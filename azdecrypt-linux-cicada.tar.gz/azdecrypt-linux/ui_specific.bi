'ui_specific.bi - platform abstraction for AZdecrypt

#ifdef __fb_linux__

    'Win32 style constants the app passes around. On Linux most are inert, but
    const WS_OVERLAPPEDWINDOW = &h0
    const WS_VISIBLE          = &h0
    const WS_DISABLED         = &h0
    const MF_CHECKED          = &h8
    const MF_UNCHECKED        = &h0
    const ES_READONLY         = &h0800
    const WS_TABSTOP          = &h0
    const ES_CENTER           = &h0
    const WS_SYSMENU          = &h0
    const WS_MINIMIZEBOX      = &h0
    const WS_GROUP            = &h20000
    const MF_SEPARATOR        = &h800

    type HWND  as any ptr
    type HMENU as any ptr

    #include once "gtk_backend.bi"
    #include once "gtk_widgets.bi"

    type msg as MSG_TYPE

    'Root menu -> owning window binding. The app creates exactly one menu bar,
    dim shared as any ptr g_menu_owner = 0

    'The first menu created by the app is the root (hmenu); submenus attach to it.
    dim shared as any ptr g_root_menu = 0

    'Ctrl key state, for the app's getkeystate(vk_control) checks.
    function getkeystate(byval vk as long) as short
        if vk = VK_CONTROL then
            if g_ctrl_down then return cast(short, &h8000)
        end if
        return 0
    end function

    'Win32 EnableWindow: grey out / re-enable a control.
    sub enablewindow(byval h as any ptr, byval en as long)
        if h = 0 then return
        gtk_widget_set_sensitive(cast(GtkWidget ptr, h), iif(en <> 0, TRUE, FALSE))
    end sub

    'Win32 UpdateWindow: force an immediate repaint. GTK repaints on its own,
    sub updatewindow(byval h as any ptr)
        if h = 0 then return
        gtk_widget_queue_draw(cast(GtkWidget ptr, h))
    end sub

#endif

'CPU core count
#ifdef __fb_linux__

    #include once "crt/unistd.bi"
    const _SC_NPROCESSORS_ONLN_ = 84   'Linux value

    function GetCPUCores as ubyte
        dim as long n = sysconf(_SC_NPROCESSORS_ONLN_)
        if n < 1 then n = 1
        if n > 255 then n = 255
        return cubyte(n)
    end function

#else

    function GetCPUCores As ubyte
        Dim As UByte numcores
        Asm
        mov eax,&h0A
        cpuid
        mov [numcores],al
        End Asm
        If numcores = 0 Then numcores = 1
        return numcores
    end function

#endif

'Edit boxes

sub ui_editbox_settext(byval hwndedit as hwnd,byval text as string,byval arg3 as string="")

    #ifdef __fb_linux__
        'Once the main loop is running, queue: the solver writes status text
        'from worker threads and GTK must only be touched by the loop.
        if uiq_deferred() then
            uiq_push(UIQ_EDIT, cast(any ptr, hwndedit), text)
        else
            gtkbe_editbox_settext(cast(any ptr, hwndedit), text)
        end if
    #else
        editbox_settext(hwndedit,text)
    #endif

end sub

function ui_editbox_gettext(byval hwndedit as hwnd)as string

    #ifdef __fb_linux__
        return gtkbe_editbox_gettext(cast(any ptr, hwndedit))
    #else
        return editbox_gettext(hwndedit)
    #endif

end function

'File dialogs

function ui_loadsavedialog(byval savedlog as long=0,byval windowname as string="",byval filter as string="",byval fltrindex as long=1,byval initdir as string="",byval strdefext as string="")as string

    #ifdef __fb_linux__
        return gtkbe_loadsavedialog(savedlog, windowname, initdir)
    #else
        return loadsavedialog(savedlog,windowname,filter,fltrindex,initdir,strdefext)
    #endif

end function

'Windows

function ui_window_new(byval x as long,byval y as long,byval w as long,byval h as long,byval title as string,byval style as ulong=WS_OVERLAPPEDWINDOW Or WS_VISIBLE)as hwnd

    #ifdef __fb_linux__
        dim as any ptr r = gtkbe_window_new(x, y, w, h, title)
        if g_menu_owner = 0 then g_menu_owner = r   'first window == window_main
        return cast(hwnd, r)
    #else
        return window_new(x,y,w,h,title,style)
    #endif

end function

sub ui_window_getposition(byval hwnd as hwnd,byref x_left as long,byref y_top as long,byref x_right as long,byref y_bottom as long)

    #ifdef __fb_linux__
        gtkbe_window_getposition(cast(any ptr, hwnd), x_left, y_top, x_right, y_bottom)
    #else
        window_getposition(hwnd,x_left,y_top,x_right,y_bottom)
    #endif

end sub

function ui_window_event_close(byval hwnd as hwnd,byref msg as msg)as long

    #ifdef __fb_linux__
        return gtkbe_window_closed(cast(any ptr, hwnd))
    #else
        return window_event_close(hwnd,msg)
    #endif

end function

sub ui_control_setfont(byval hwndcontrol as hwnd,byval font as string,byval h as long=16,byval w as long=8,byval wt as long=0,byval it as long=false,byval ul as long=false,byval so as long=false)

    #ifdef __fb_linux__
        gtkbe_control_setfont(cast(any ptr, hwndcontrol), font, h)
    #else
        control_setfont(hwndcontrol,font,h,w,wt,it,ul,so)
    #endif

end sub

'Buttons, checkboxes, radio buttons

function ui_button_new(byval x as long,byval y as long,byval w as long,byval h as long,byval label as string,byval style as ulong=WS_TABSTOP,byval hwnd as hwnd)as hwnd

    #ifdef __fb_linux__
        return cast(hwnd, gtkbe_button_new(x, y, w, h, label, cast(any ptr, hwnd)))
    #else
        return button_new(x,y,w,h,label,style,hwnd)
    #endif

end function

function ui_checkbox_new(byval x as long,byval y as long,byval w as long,byval h as long,byval label as string,byval style as ulong=WS_TABSTOP,byval hwnd as hwnd)as hwnd

    #ifdef __fb_linux__
        return cast(hwnd, gtkbe_checkbox_new(x, y, w, h, label, cast(any ptr, hwnd)))
    #else
        return checkbox_new(x,y,w,h,label,style,hwnd)
    #endif

end function

sub ui_checkbox_setcheck(byval hwndcheck as hwnd,byval checkstate as long)

    #ifdef __fb_linux__
        gtkbe_checkbox_setcheck(cast(any ptr, hwndcheck), checkstate)
    #else
        checkbox_setcheck(hwndcheck,checkstate)
    #endif

end sub

function ui_checkbox_getcheck(byval hwndcheck as hwnd)as long

    #ifdef __fb_linux__
        return gtkbe_checkbox_getcheck(cast(any ptr, hwndcheck))
    #else
        return checkbox_getcheck(hwndcheck)
    #endif

end function

function ui_radiobutton_new(byval x as long,byval y as long,byval w as long,byval h as long,byval label as string,byval style as long=WS_TABSTOP,byval hwnd as hwnd)as hwnd

    #ifdef __fb_linux__
        dim as long isgroup = 0
        if (style and WS_GROUP) <> 0 then isgroup = 1
        return cast(hwnd, gtkbe_radiobutton_new(x, y, w, h, label, isgroup, cast(any ptr, hwnd)))
    #else
        return radiobutton_new(x,y,w,h,label,style,hwnd)
    #endif

end function

sub ui_radiobutton_setcheck(byval hwndradio as hwnd,byval checkstate as long)

    #ifdef __fb_linux__
        gtkbe_radiobutton_setcheck(cast(any ptr, hwndradio), checkstate)
    #else
        radiobutton_setcheck(hwndradio,checkstate)
    #endif

end sub

function ui_radiobutton_getcheck(byval hwndradio as hwnd)as long

    #ifdef __fb_linux__
        return gtkbe_radiobutton_getcheck(cast(any ptr, hwndradio))
    #else
        return radiobutton_getcheck(hwndradio)
    #endif

end function

'Labels

function ui_label_new(byval x as long,byval y as long,byval w as long,byval h as long,byval text as string,byval style as ulong=0,byval hwnd as hwnd)as hwnd

    #ifdef __fb_linux__
        return cast(hwnd, gtkbe_label_new(x, y, w, h, text, cast(any ptr, hwnd)))
    #else
        return label_new(x,y,w,h,text,style,hwnd)
    #endif

end function

sub ui_label_settext(byval hwndlabel as hwnd,byval text as string)

    #ifdef __fb_linux__
        gtkbe_label_settext(cast(any ptr, hwndlabel), text)
    #else
        label_settext(hwndlabel,text)
    #endif

end sub

'Edit / editor creation

function ui_editbox_new(byval x as long,byval y as long,byval w as long,byval h as long,byval text as string,byval style as ulong=WS_TABSTOP,byval hwnd as hwnd)as hwnd

    #ifdef __fb_linux__
        dim as long ro = 0
        if (style and ES_READONLY) <> 0 then ro = 1
        return cast(hwnd, gtkbe_editbox_new(x, y, w, h, text, ro, cast(any ptr, hwnd)))
    #else
        return editbox_new(x,y,w,h,text,style,hwnd)
    #endif

end function

function ui_editor_new(byval x as long,byval y as long,byval w as long,byval h as long,byval text as string,byval style as ulong=WS_TABSTOP,byval hwnd as hwnd)as hwnd

    #ifdef __fb_linux__
        dim as long ro = 0
        if (style and ES_READONLY) <> 0 then ro = 1
        return cast(hwnd, gtkbe_editor_new(x, y, w, h, text, ro, cast(any ptr, hwnd)))
    #else
        return editor_new(x,y,w,h,text,style,hwnd)
    #endif

end function

'List boxes

function ui_listbox_new(byval x as long,byval y as long,byval w as long,byval h as long,byval style as ulong=WS_TABSTOP,byval hwnd as hwnd)as hwnd

    #ifdef __fb_linux__
        return cast(hwnd, gtkbe_listbox_new(x, y, w, h, cast(any ptr, hwnd)))
    #else
        return listbox_new(x,y,w,h,style,hwnd)
    #endif

end function

sub ui_listbox_addstring(byval hwndlist as hwnd,byval text as string)

    #ifdef __fb_linux__
        gtkbe_listbox_addstring(cast(any ptr, hwndlist), text)
    #else
        listbox_addstring(hwndlist,text)
    #endif

end sub

sub ui_listbox_deletestring(byval hwndlist as hwnd,byval index as long)

    #ifdef __fb_linux__
        gtkbe_listbox_deletestring(cast(any ptr, hwndlist), index)
    #else
        listbox_deletestring(hwndlist,index)
    #endif

end sub

sub ui_listbox_replacestring(byval hwndlist as hwnd,byval index as long,byval text as string,byval newdata as long=0)

    #ifdef __fb_linux__
        if uiq_deferred() then
            uiq_push(UIQ_LISTREP, cast(any ptr, hwndlist), text, index)
        else
            gtkbe_listbox_replacestring(cast(any ptr, hwndlist), index, text)
        end if
    #else
        listbox_replacestring(hwndlist,index,text,newdata)
    #endif

end sub

sub ui_listbox_resetcontent(byval hwndlist as hwnd)

    #ifdef __fb_linux__
        gtkbe_listbox_resetcontent(cast(any ptr, hwndlist))
    #else
        listbox_resetcontent(hwndlist)
    #endif

end sub

sub ui_listbox_setcursel(byval hwndlist as hwnd,byval index as long)

    #ifdef __fb_linux__
        gtkbe_listbox_setcursel(cast(any ptr, hwndlist), index)
    #else
        listbox_setcursel(hwndlist,index)
    #endif

end sub

function ui_listbox_getcursel(byval hwndlist as hwnd)as long

    #ifdef __fb_linux__
        return gtkbe_listbox_getcursel(cast(any ptr, hwndlist))
    #else
        return listbox_getcursel(hwndlist)
    #endif

end function

function ui_listbox_gettext(byval hwndlist as hwnd,byval index as long)as string

    #ifdef __fb_linux__
        return gtkbe_listbox_gettext(cast(any ptr, hwndlist), index)
    #else
        return listbox_gettext(hwndlist,index)
    #endif

end function

'Menus

sub ui_menutitle(byval hmenu as hmenu,byval hmenutitle as hmenu,byval title as string)

    #ifdef __fb_linux__
        if cast(any ptr, hmenu) = g_root_menu then
            'Top level: attach to the owning window's menu bar.
            gtkbe_menutitle(g_menu_owner, cast(any ptr, hmenutitle), title)
        else
            'Nested: add an item to the parent menu carrying the submenu.
            dim as GtkWidget ptr it = gtk_menu_item_new_with_label(title)
            gtk_menu_item_set_submenu(GTK_MENU_ITEM(it), cast(GtkWidget ptr, hmenutitle))
            gtk_menu_shell_append(GTK_MENU_SHELL(cast(GtkWidget ptr, hmenu)), it)
            gtk_widget_show(it)
        end if
    #else
        menutitle(hmenu,hmenutitle,title)
    #endif

end sub

sub ui_menuitem(byval hmenutitle as hmenu,byval menuitemnumber as long,byval menuitemname as string)

    #ifdef __fb_linux__
        gtkbe_menuitem(cast(any ptr, hmenutitle), menuitemnumber, menuitemname, g_menu_owner)
    #else
        menuitem(hmenutitle,menuitemnumber,menuitemname)
    #endif

end sub

function ui_createmenu()as hmenu

    #ifdef __fb_linux__
        dim as any ptr m = gtkbe_createmenu()
        if g_root_menu = 0 then g_root_menu = m   'first menu created is the root
        return cast(hmenu, m)
    #else
        return createmenu()
    #endif

end function

sub ui_appendmenu(byval hmenu as hmenu,byval style as ulong,byval index as long,byval text as string="")

    #ifdef __fb_linux__
        if (style and MF_SEPARATOR) <> 0 then
            gtkbe_menuitem(cast(any ptr, hmenu), index, "-", g_menu_owner)
        else
            gtkbe_menuitem(cast(any ptr, hmenu), index, text, g_menu_owner)
        end if
    #else
        appendmenu(hmenu,style,index,text)
    #endif

end sub

sub ui_modifymenu(byval hmenu as hmenu,byval index1 as long,byval msg as long,byval index2 as long,byval text as string)

    #ifdef __fb_linux__
        'Used to rename / check-mark items. Reflect the text; prefix a marker
        if (msg and MF_CHECKED) <> 0 then
            gtkbe_menu_settext(cast(any ptr, hmenu), index2, "* " & text)
        else
            gtkbe_menu_settext(cast(any ptr, hmenu), index2, text)
        end if
    #else
        modifymenu(hmenu,index1,msg,index2,text)
    #endif

end sub

sub ui_drawmenubar(byval hwnd as hwnd)

    #ifdef __fb_linux__
        gtkbe_drawmenubar(cast(any ptr, hwnd))
    #else
        drawmenubar(hwnd)
    #endif

end sub

sub ui_setmenu(byval hwnd as hwnd,byval hmenu as hmenu)

    #ifdef __fb_linux__
        gtkbe_setmenu(cast(any ptr, hwnd), cast(any ptr, hmenu))
    #else
        setmenu(hwnd,hmenu)
    #endif

end sub

'Misc window operations

sub ui_seticon(byval hwnd as hwnd)

    #ifdef __fb_linux__
        'Icon comes from the .desktop file / window manager on Linux.
    #else
        dim hicon as hicon=loadimage(getmodulehandle(null),"fb_program_icon",image_icon,256,256,lr_shared)
        sendmessage(hwnd,wm_seticon,cast(wparam,icon_big),cast(lparam,hicon))
    #endif

end sub

sub ui_destroywindow(byval hwnd as hwnd)

    #ifdef __fb_linux__
        'Hide, not destroy: the app reopens these sub-windows by handle.
        gtkbe_window_hide(cast(any ptr, hwnd))
    #else
        destroywindow(hwnd)
    #endif

end sub

sub ui_sendmessage(byval hwnd as hwnd,byval msg as long,byval arg1 as long,byval arg2 as long)

    #ifdef __fb_linux__
        'Only EM_SETSEL(0,-1) "select all" is used by the app.
        if msg = EM_SETSEL then gtkbe_editbox_selectall(cast(any ptr, hwnd))
    #else
        sendmessage(hwnd,msg,arg1,arg2)
    #endif

end sub

sub ui_setfocus(byval hwnd as hwnd)

    #ifdef __fb_linux__
        gtkbe_setfocus(cast(any ptr, hwnd))
    #else
        setfocus(hwnd)
    #endif

end sub

sub ui_setwindowtext(byval hwnd as hwnd,byval text as string)

    #ifdef __fb_linux__
        if uiq_deferred() then
            uiq_push(UIQ_TITLE, cast(any ptr, hwnd), text)
        else
            gtkbe_setwindowtext(cast(any ptr, hwnd), text)
        end if
    #else
        setwindowtext(hwnd,text)
    #endif

end sub

'Yes/No confirmation. Returns 1 for Yes, 0 for No.
function ui_confirm(byval title as string,byval message as string)as long

    #ifdef __fb_linux__
        return gtkbe_confirm(title, message)
    #else
        if messagebox(0,message,title,MB_YESNO or MB_ICONQUESTION)=IDYES then return 1
        return 0
    #endif

end function
